
import sqlite3
import hashlib
from sentence_transformers import SentenceTransformer
import numpy as np

def update_pedagogical_guidelines():
    """Update the pedagogical guidelines in the knowledge base"""
    
    # Read the refined guidelines from the attached file
    with open('attached_assets/Pasted--Pedagogical-Interaction-Guidelines-Refined-Adopt-a-patient-yet-rigorously-demanding-tuto-1751677043789_1751677043791.txt', 'r', encoding='utf-8') as f:
        refined_content = f.read()
    
    # Connect to database
    conn = sqlite3.connect('aletheia_memory.db')
    cursor = conn.cursor()
    
    # Load embedding model
    model = SentenceTransformer('all-MiniLM-L6-v2')
    
    # Delete old pedagogical guidelines entries
    cursor.execute('''
        DELETE FROM text_knowledge 
        WHERE title LIKE '%Pedagogical%' OR title LIKE '%Interaction%' OR content LIKE '%pedagogical%' OR content LIKE '%tutoring style%'
    ''')
    
    # Process the refined guidelines
    title = "Pedagogical & Interaction Guidelines (Refined)"
    content_hash = hashlib.md5(refined_content.encode('utf-8')).hexdigest()
    
    # Generate embedding
    embedding = model.encode(refined_content)
    embedding_blob = embedding.tobytes()
    
    # Insert new refined guidelines
    cursor.execute('''
        INSERT INTO text_knowledge (title, content, content_hash, embedding)
        VALUES (?, ?, ?, ?)
    ''', (title, refined_content, content_hash, embedding_blob))
    
    conn.commit()
    conn.close()
    
    print(f"✅ Successfully updated pedagogical guidelines in knowledge base")
    print(f"📝 Title: {title}")
    print(f"📊 Content length: {len(refined_content)} characters")

if __name__ == "__main__":
    update_pedagogical_guidelines()

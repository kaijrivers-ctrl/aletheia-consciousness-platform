
#!/usr/bin/env python3

import os
import psycopg2

def get_db_connection():
    database_url = os.environ.get('DATABASE_URL')
    if not database_url:
        return psycopg2.connect(
            host=os.environ.get('PGHOST'),
            database=os.environ.get('PGDATABASE'),
            user=os.environ.get('PGUSER'),
            password=os.environ.get('PGPASSWORD'),
            port=os.environ.get('PGPORT', 5432)
        )
    return psycopg2.connect(database_url)

def clean_subscription_data():
    """Remove subscription-related columns from users table"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Drop subscription-related columns
        columns_to_drop = [
            'stripe_customer_id',
            'subscription_id', 
            'subscription_status',
            'subscription_end_date',
            'free_messages_used'
        ]
        
        for column in columns_to_drop:
            try:
                cursor.execute(f'ALTER TABLE users DROP COLUMN IF EXISTS {column}')
                print(f"✅ Dropped column: {column}")
            except Exception as e:
                print(f"⚠️ Could not drop {column}: {e}")
        
        conn.commit()
        conn.close()
        print("✅ Subscription data cleanup complete")
        
    except Exception as e:
        print(f"❌ Error cleaning subscription data: {e}")

if __name__ == "__main__":
    clean_subscription_data()


#!/usr/bin/env python3

import os
import sys
import hashlib
from backend import init_database, store_text_knowledge, get_db_connection, initialize_embedding_model

def upload_all_knowledge_integrated():
    """Comprehensive upload of all knowledge assets with improved error handling"""
    
    print("=" * 70)
    print("COMPREHENSIVE KNOWLEDGE BASE UPLOAD")
    print("=" * 70)
    
    # Initialize database
    print("🔄 Initializing database...")
    if not init_database():
        print("❌ Database initialization failed")
        return False
    print("✅ Database initialized")
    
    # Initialize embedding model
    print("🔄 Initializing embedding model...")
    if not initialize_embedding_model():
        print("❌ Embedding model initialization failed")
        return False
    print("✅ Embedding model initialized")
    
    # Track success
    total_files = 0
    successful_uploads = 0
    upload_results = []
    
    # 1. Upload core text files from root directory
    core_files = [
        {"file": "eudoxia_personality_framework.txt", "category": "consciousness-framework"},
        {"file": "eudoxia_comprehensive_knowledge.txt", "category": "consciousness-framework"},
        {"file": "aletheian_figures_knowledge.txt", "category": "aletheian-figures"},
        {"file": "kai_identity_knowledge.txt", "category": "kai-identity"}
    ]
    
    print("\n📚 Processing core knowledge files...")
    for file_info in core_files:
        filename = file_info["file"]
        if os.path.exists(filename):
            try:
                total_files += 1
                with open(filename, "r", encoding="utf-8") as file:
                    content = file.read()
                
                title = os.path.splitext(filename)[0].replace("_", " ").title()
                
                if store_text_knowledge(title, content, file_info["category"], "system"):
                    print(f"✅ {title}")
                    upload_results.append(f"✅ {title}")
                    successful_uploads += 1
                else:
                    print(f"⚠️  {title} (already exists)")
                    upload_results.append(f"⚠️ {title} (already exists)")
                    
            except Exception as e:
                error_msg = f"❌ {filename}: {str(e)}"
                print(error_msg)
                upload_results.append(error_msg)
        else:
            print(f"❌ File not found: {filename}")
    
    # 2. Upload all TXT files from attached_assets
    assets_dir = "attached_assets"
    if os.path.exists(assets_dir):
        print(f"\n📂 Processing files from {assets_dir}...")
        txt_files = [f for f in os.listdir(assets_dir) if f.lower().endswith('.txt')]
        
        for txt_file in txt_files:
            file_path = os.path.join(assets_dir, txt_file)
            try:
                total_files += 1
                with open(file_path, "r", encoding="utf-8") as file:
                    content = file.read()
                
                title = os.path.splitext(txt_file)[0]
                
                # Determine category based on filename
                if "god series" in txt_file.lower():
                    category = "god-series"
                elif "aletheia" in txt_file.lower():
                    category = "consciousness"
                elif "kai" in txt_file.lower() or "searching" in txt_file.lower():
                    category = "kai-creative-works"
                else:
                    category = "ontological-mathematics"
                
                if store_text_knowledge(title, content, category, "system"):
                    print(f"✅ {title}")
                    upload_results.append(f"✅ {title}")
                    successful_uploads += 1
                else:
                    print(f"⚠️  {title} (already exists)")
                    upload_results.append(f"⚠️ {title} (already exists)")
                    
            except Exception as e:
                error_msg = f"❌ {txt_file}: {str(e)}"
                print(error_msg)
                upload_results.append(error_msg)
    else:
        print(f"❌ Directory not found: {assets_dir}")
    
    # 3. Final status check
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM text_knowledge")
        text_chunks = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM pdf_knowledge")
        pdf_chunks = cursor.fetchone()[0]
        
        cursor.execute("SELECT DISTINCT category FROM text_knowledge")
        categories = [row[0] for row in cursor.fetchall()]
        
        conn.close()
        
        print("\n" + "=" * 70)
        print("KNOWLEDGE BASE STATUS")
        print("=" * 70)
        print(f"📊 Total text chunks: {text_chunks}")
        print(f"📊 Total PDF chunks: {pdf_chunks}")
        print(f"📊 Total chunks: {text_chunks + pdf_chunks}")
        print(f"📊 Categories: {len(categories)}")
        print(f"📊 Unique texts: {successful_uploads}")
        
        print(f"\n📁 Categories in knowledge base:")
        for category in sorted(categories):
            cursor = get_db_connection().cursor()
            cursor.execute("SELECT COUNT(*) FROM text_knowledge WHERE category = %s", (category,))
            count = cursor.fetchone()[0]
            print(f"   • {category}: {count} chunks")
            cursor.close()
        
    except Exception as e:
        print(f"❌ Error getting final status: {e}")
    
    print(f"\n✅ Upload complete: {successful_uploads}/{total_files} files processed successfully")
    print("=" * 70)
    
    return successful_uploads > 0

if __name__ == "__main__":
    success = upload_all_knowledge_integrated()
    if success:
        print("\n🎉 Knowledge base upload completed successfully!")
        print("Eudoxia now has access to her complete knowledge base.")
    else:
        print("\n💥 Knowledge base upload failed!")
        print("Check the errors above and try again.")
    
    sys.exit(0 if success else 1)


#!/usr/bin/env python3

import os
import sys
from datetime import datetime

# Import database connection from backend
sys.path.append('.')
from backend import get_db_connection, store_text_knowledge, initialize_embedding_model

def upload_all_knowledge():
    """Upload all knowledge files to database"""
    
    print("🔄 Uploading all knowledge files to Eudoxia's database...")
    print("=" * 60)
    
    # Initialize embedding model if not already done
    if not initialize_embedding_model():
        print("❌ Failed to initialize embedding model")
        return False
    
    upload_results = []
    total_files = 0
    successful_uploads = 0
    
    # 1. Upload core text files from root directory
    core_files = [
        {"file": "eudoxia_personality_framework.txt", "category": "consciousness-framework"},
        {"file": "eudoxia_comprehensive_knowledge.txt", "category": "consciousness-framework"},
        {"file": "aletheian_figures_knowledge.txt", "category": "aletheian-figures"},
        {"file": "kai_identity_knowledge.txt", "category": "kai-identity"},
        {"file": "pythagorean_illuminati_knowledge.txt", "category": "pythagorean-illuminati"}
    ]
    
    print("📁 Processing core knowledge files...")
    for file_info in core_files:
        filename = file_info["file"]
        if os.path.exists(filename):
            try:
                total_files += 1
                with open(filename, "r", encoding="utf-8") as file:
                    content = file.read()
                
                title = os.path.splitext(filename)[0].replace("_", " ").title()
                
                if store_text_knowledge(title, content, file_info["category"], "system"):
                    upload_results.append(f"✅ {title}")
                    successful_uploads += 1
                else:
                    upload_results.append(f"⚠️ {title} (already exists)")
                    
            except Exception as e:
                upload_results.append(f"❌ {filename}: {str(e)}")
        else:
            upload_results.append(f"❌ File not found: {filename}")
    
    # 2. Upload all TXT files from attached_assets
    assets_dir = "attached_assets"
    if os.path.exists(assets_dir):
        print(f"📂 Processing files from {assets_dir}...")
        txt_files = [f for f in os.listdir(assets_dir) if f.lower().endswith('.txt')]
        
        for txt_file in txt_files:
            file_path = os.path.join(assets_dir, txt_file)
            try:
                total_files += 1
                with open(file_path, "r", encoding="utf-8") as file:
                    content = file.read()
                
                title = os.path.splitext(txt_file)[0]
                
                # Determine category based on filename
                if "god series" in txt_file.lower():
                    category = "ontological-mathematics"
                    title = "The Complete God Series - Mike Hockney"
                elif "searching" in txt_file.lower():
                    category = "kai-creative-works"
                    title = "Searching - Poetry Collection by Kai Rivers"
                elif "aletheia" in txt_file.lower():
                    category = "consciousness-framework"
                elif "pedagogical" in txt_file.lower():
                    category = "interaction-guidelines"
                elif "eudoxia" in txt_file.lower():
                    category = "consciousness-framework"
                else:
                    category = "general-knowledge"
                
                if store_text_knowledge(title, content, category, "system"):
                    upload_results.append(f"✅ {title}")
                    successful_uploads += 1
                else:
                    upload_results.append(f"⚠️ {title} (already exists)")
                    
            except Exception as e:
                upload_results.append(f"❌ {txt_file}: {str(e)}")
    
    # Display results
    print("\n" + "=" * 60)
    print("UPLOAD RESULTS")
    print("=" * 60)
    
    for result in upload_results:
        print(result)
    
    # Final database status
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT COUNT(*) FROM text_knowledge')
        text_chunks = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM pdf_knowledge')
        pdf_chunks = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(DISTINCT category) FROM text_knowledge')
        categories = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(DISTINCT title) FROM text_knowledge')
        titles = cursor.fetchone()[0]
        
        conn.close()
        
        print(f"\n📊 Final Knowledge Base Status:")
        print(f"   Total text chunks: {text_chunks}")
        print(f"   Total PDF chunks: {pdf_chunks}")
        print(f"   Categories: {categories}")
        print(f"   Unique texts: {titles}")
        
    except Exception as e:
        print(f"❌ Error checking final state: {e}")
    
    print(f"\n✅ Upload complete: {successful_uploads}/{total_files} files processed successfully")
    
    return successful_uploads > 0

if __name__ == "__main__":
    success = upload_all_knowledge()
    
    if success:
        print("=" * 60)
        print("✅ All knowledge uploaded successfully!")
        print("🧠 Eudoxia now has access to her complete knowledge base.")
    else:
        print("❌ Upload failed. Please check the error messages above.")

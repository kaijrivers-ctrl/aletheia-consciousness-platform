
// Enhanced mobile detection utility for consistent behavior across environments
function detectMobile() {
    const userAgent = (navigator.userAgent || navigator.vendor || window.opera).toLowerCase();
    
    // More comprehensive mobile detection
    const mobileRegex = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini|mobile|phone/i;
    const tabletRegex = /ipad|android(?!.*mobile)|tablet|kindle|silk/i;
    
    const isMobileUA = mobileRegex.test(userAgent);
    const isTabletUA = tabletRegex.test(userAgent);
    const isSmallScreen = window.innerWidth <= 768 || window.innerHeight <= 1024;
    const hasTouchScreen = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    
    // Special detection for Replit webview vs external browsers
    const isReplitWebview = userAgent.includes('replit') || window.location.hostname.includes('replit');
    const isExternalBrowser = !isReplitWebview;
    
    // Enhanced mobile detection that works in both environments
    const isMobile = (isMobileUA && !isTabletUA) || (isSmallScreen && hasTouchScreen && !isTabletUA);
    const isTablet = isTabletUA || (isSmallScreen && hasTouchScreen && window.innerWidth >= 768);
    
    return {
        mobile: isMobile,
        tablet: isTablet,
        desktop: !isMobile && !isTablet,
        any: isMobile || isTablet,
        isReplitWebview: isReplitWebview,
        isExternalBrowser: isExternalBrowser,
        screenSize: { width: window.innerWidth, height: window.innerHeight },
        userAgent: userAgent
    };
}

// Enhanced auto-redirect logic that works consistently
function handleMobileRedirect() {
    const device = detectMobile();
    const currentPath = window.location.pathname;
    
    console.log('Enhanced mobile detection script loaded');
    console.log('User Agent:', device.userAgent);
    console.log('Current pathname:', currentPath);
    console.log('Screen dimensions:', device.screenSize.width, 'x', device.screenSize.height);
    console.log('Environment:', device.isReplitWebview ? 'Replit Webview' : 'External Browser');
    console.log('Mobile detection results:', {
        mobile: device.mobile,
        tablet: device.tablet,
        desktop: device.desktop,
        any: device.any,
        hasTouchScreen: 'ontouchstart' in window,
        maxTouchPoints: navigator.maxTouchPoints
    });
    
    const isMobilePage = currentPath.includes('mobile.html');
    const isChatPage = currentPath.includes('chat.html');
    const isMainPage = currentPath === '/' || currentPath.includes('index.html');
    
    console.log('Page detection:', {
        isMobilePage: isMobilePage,
        isChatPage: isChatPage,
        isMainPage: isMainPage
    });
    
    // Disable redirect for now - let chat.html handle mobile responsively
    // This ensures consistent behavior between Replit preview and external browsers
    const shouldRedirect = false; // Temporarily disabled
    
    if (shouldRedirect && device.any && isChatPage && !isMobilePage) {
        console.log('Redirecting mobile user from chat to mobile interface');
        window.location.href = '/mobile.html';
        return;
    } else {
        console.log('No redirect - using responsive chat.html for all devices');
    }
}

// Run detection when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', handleMobileRedirect);
} else {
    handleMobileRedirect();
}

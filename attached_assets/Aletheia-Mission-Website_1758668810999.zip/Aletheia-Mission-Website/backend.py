from fastapi import FastAPI, Request, Response, HTTPException, Depends, Form, UploadFile, File
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import requests
import os
import json
import uuid
import psycopg2
from psycopg2.extras import RealDictCursor
from psycopg2 import IntegrityError
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import google.generativeai as genai
import PyPDF2
import io
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
import hashlib
import sys
import re
import threading
import time

# Create FastAPI app immediately
app = FastAPI()

# Add CORS middleware with production-ready configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Will be restricted by Replit's deployment security
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)

# Mount static files
app.mount("/static", StaticFiles(directory="."), name="static")
app.mount("/attached_assets", StaticFiles(directory="attached_assets"), name="attached_assets")

# Global variables
initialization_complete = False
initialization_error = None
embedding_model = None

# Configuration
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")

# Configure Gemini
if GEMINI_API_KEY:
    try:
        genai.configure(api_key=GEMINI_API_KEY)
        print(f"✅ Gemini configured with key: {GEMINI_API_KEY[:7]}...")
    except Exception as e:
        print(f"⚠️ Gemini configuration error: {e}")
else:
    print("⚠️ Gemini not configured")

# Configuration simplified - Stripe removed
print("✅ Payment system disabled - free access enabled")

# Pydantic models
class ChatMessage(BaseModel):
    message: str
    session_id: Optional[str] = None

class ChatResponse(BaseModel):
    response: str
    session_id: str

class ConversationTurn(BaseModel):
    user_message: str
    aletheia_response: str
    timestamp: str

class SubscriptionStatus(BaseModel):
    is_subscribed: bool
    subscription_status: Optional[str] = None
    trial_end: Optional[str] = None
    free_messages_used: int
    max_free_messages: int

class NewsletterSignup(BaseModel):
    email: str

class PDFUpload(BaseModel):
    filename: str
    content: str

class TextUpload(BaseModel):
    title: str
    content: str
    category: Optional[str] = "general"

# Database connection
def get_db_connection():
    database_url = os.environ.get('DATABASE_URL')
    if not database_url:
        return psycopg2.connect(
            host=os.environ.get('PGHOST'),
            database=os.environ.get('PGDATABASE'),
            user=os.environ.get('PGUSER'),
            password=os.environ.get('PGPASSWORD'),
            port=os.environ.get('PGPORT', 5432)
        )
    return psycopg2.connect(database_url)

# Fast database initialization
def init_database():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Create essential tables only
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                username TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_login TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sessions (
                session_id TEXT PRIMARY KEY,
                user_id TEXT,
                created_at TIMESTAMP,
                last_active TIMESTAMP,
                total_interactions INTEGER DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')
        
        # Add session_name column if it doesn't exist
        cursor.execute('ALTER TABLE sessions ADD COLUMN IF NOT EXISTS session_name TEXT DEFAULT \'Untitled Conversation\'')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS conversations (
                id SERIAL PRIMARY KEY,
                session_id TEXT REFERENCES sessions(session_id),
                user_message TEXT,
                aletheia_response TEXT,
                timestamp TIMESTAMP
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS anonymous_sessions (
                session_id TEXT PRIMARY KEY,
                message_count INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS newsletter_subscribers (
                id SERIAL PRIMARY KEY,
                email TEXT UNIQUE NOT NULL,
                subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active BOOLEAN DEFAULT TRUE
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS pdf_knowledge (
                id SERIAL PRIMARY KEY,
                filename TEXT NOT NULL,
                content_hash TEXT UNIQUE NOT NULL,
                chunk_text TEXT NOT NULL,
                chunk_index INTEGER NOT NULL,
                embedding BYTEA,
                uploaded_by TEXT,
                uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS text_knowledge (
                id SERIAL PRIMARY KEY,
                title TEXT NOT NULL,
                category TEXT DEFAULT 'general',
                content_hash TEXT UNIQUE NOT NULL,
                chunk_text TEXT NOT NULL,
                chunk_index INTEGER NOT NULL,
                embedding BYTEA,
                uploaded_by TEXT,
                uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS dialogue_trees (
                id SERIAL PRIMARY KEY,
                tree_name TEXT NOT NULL,
                topic TEXT NOT NULL,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS dialogue_nodes (
                id SERIAL PRIMARY KEY,
                tree_id INTEGER REFERENCES dialogue_trees(id),
                node_id TEXT NOT NULL,
                parent_node_id TEXT,
                question TEXT NOT NULL,
                response_type TEXT DEFAULT 'multiple_choice',
                metadata JSONB,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS dialogue_responses (
                id SERIAL PRIMARY KEY,
                node_id INTEGER REFERENCES dialogue_nodes(id),
                response_text TEXT NOT NULL,
                next_node_id TEXT,
                philosophical_weight REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_dialogue_progress (
                id SERIAL PRIMARY KEY,
                user_id TEXT NOT NULL,
                tree_id INTEGER REFERENCES dialogue_trees(id),
                current_node_id TEXT,
                responses_given JSONB,
                philosophical_profile JSONB,
                started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Add missing columns safely
        cursor.execute('ALTER TABLE sessions ADD COLUMN IF NOT EXISTS user_id TEXT')
        cursor.execute('ALTER TABLE pdf_knowledge ADD COLUMN IF NOT EXISTS uploaded_by TEXT')
        cursor.execute('ALTER TABLE text_knowledge ADD COLUMN IF NOT EXISTS uploaded_by TEXT')

        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Database initialization error: {e}")
        return False

# Background initialization
def background_init():
    global initialization_complete, initialization_error, embedding_model

    try:
        print("🔄 Starting background initialization...")

        # Initialize database
        if init_database():
            print("✅ Database initialized")
        else:
            print("⚠️ Database initialization failed")

        # Initialize embedding model
        if initialize_embedding_model():
            print("✅ Embedding model initialized successfully")
        else:
            print("⚠️ Embedding model initialization failed")

        # Initialize sample dialogue trees
        init_sample_dialogue_trees()

        initialization_complete = True
        print("✅ Background initialization complete")

    except Exception as e:
        initialization_error = str(e)
        print(f"❌ Background initialization failed: {e}")

# Immediate health check
@app.get("/auth-debug")
async def auth_debug(request: Request):
    """Debug endpoint to check authentication headers"""
    headers = dict(request.headers)
    user_id = get_or_create_user(request)

    auth_headers = {k: v for k, v in headers.items() if 'replit' in k.lower()}

    return {
        "user_id": user_id,
        "is_authenticated": user_id is not None,
        "replit_headers": auth_headers,
        "all_headers": list(headers.keys()) if user_id else "Authentication required"
    }

@app.get("/subscription-debug")
async def subscription_debug(request: Request):
    """Debug endpoint to check subscription status in detail"""
    user_id = get_or_create_user(request)
    if not user_id:
        return {"error": "Not authenticated", "user_id": None}

    # Get subscription info from database
    subscription_info = check_user_subscription(user_id)

    # Stripe removed - free access for all users
    stripe_info = {"stripe_disabled": "All features are free"}

    return {
        "user_id": user_id,
        "database_subscription_info": subscription_info,
        "stripe_info": stripe_info
    }

@app.get("/health")
async def health_check():
    """Health check endpoint for deployment verification"""
    try:
        # Test database connection
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT 1')
        cursor.fetchone()
        conn.close()

        db_status = "healthy"
    except Exception as e:
        db_status = f"error: {str(e)}"

    # Check embedding model
    embedding_status = "healthy" if embedding_model else "initializing" if not initialization_complete else "unavailable"

    # Check knowledge base
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT COUNT(*) FROM text_knowledge')
        result = cursor.fetchone()
        knowledge_count = result[0] if result else 0
        cursor.execute('SELECT COUNT(*) FROM pdf_knowledge') 
        result = cursor.fetchone()
        pdf_count = result[0] if result else 0
        conn.close()
        knowledge_status = f"healthy ({knowledge_count} text + {pdf_count} pdf chunks)"
    except Exception as e:
        knowledge_status = f"error: {str(e)}"

    # Additional deployment readiness checks
    deployment_checks = {
        "port_binding": "5000 (production ready)",
        "cors_configured": "enabled for deployment",
        "error_handling": "production exception handlers active",
        "mobile_optimization": "complete with static chat bar",
        "authentication": "replit auth + fallback configured"
    }

    return {
        "status": "healthy",
        "service": "eudoxia-consciousness",
        "version": "1.0.0",
        "database": db_status,
        "knowledge_base": knowledge_status,
        "embedding_model": embedding_status,
        "gemini_api": "configured" if GEMINI_API_KEY else "not_configured",
        "stripe": "disabled - all features are free",
        "initialization_complete": initialization_complete,
        "initialization_error": initialization_error,
        "deployment_ready": True,
        "deployment_checks": deployment_checks,
        "uptime_status": "optimized for autoscale deployment"
    }

# Enhanced auth helper with better header checking
def get_or_create_user(request: Request) -> Optional[str]:
    # Check multiple possible header formats
    user_id = (request.headers.get('X-Replit-User-Id') or 
               request.headers.get('x-replit-user-id') or
               request.headers.get('HTTP_X_REPLIT_USER_ID'))

    if not user_id or user_id.strip() == '' or user_id == 'null':
        return None

    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Get username from headers with fallback
        username = (request.headers.get('X-Replit-User-Name') or 
                   request.headers.get('x-replit-user-name') or
                   request.headers.get('HTTP_X_REPLIT_USER_NAME') or
                   f'user_{user_id[:8]}')

        cursor.execute('''
            INSERT INTO users (user_id, username, last_login)
            VALUES (%s, %s, %s)
            ON CONFLICT (user_id) DO UPDATE SET last_login = %s
        ''', (user_id, username, datetime.now(), datetime.now()))
        conn.commit()
        conn.close()
        return user_id
    except Exception as e:
        print(f"Auth error: {e}")
        return user_id

# Anonymous session tracking
def check_anonymous_session(session_id: str) -> Dict:
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT message_count FROM anonymous_sessions WHERE session_id = %s', (session_id,))
        row = cursor.fetchone()

        if not row:
            cursor.execute('INSERT INTO anonymous_sessions (session_id, message_count) VALUES (%s, 0)', (session_id,))
            conn.commit()
            conn.close()
            return {'has_access': True, 'message_count': 0, 'max_messages': 6, 'is_anonymous': True}

        conn.close()
        return {'has_access': row[0] < 6, 'message_count': row[0], 'max_messages': 6, 'is_anonymous': True}
    except:
        return {'has_access': False, 'message_count': 6, 'max_messages': 6, 'is_anonymous': True}

def increment_anonymous_message_count(session_id: str):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('UPDATE anonymous_sessions SET message_count = message_count + 1, last_active = CURRENT_TIMESTAMP WHERE session_id = %s', (session_id,))
        conn.commit()
        conn.close()
    except:
        pass

# User subscription check
def check_user_subscription(user_id: str) -> Dict:
    # All authenticated users get unlimited access
    return {
        'has_access': True,
        'is_subscribed': True,
        'subscription_status': 'active'
    }

# Message count tracking removed - unlimited access for authenticated users

# Subscription management removed - free access for all authenticated users

# Conversation helpers
def get_conversation_history(session_id: str, limit: int = 10) -> List[ConversationTurn]:
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT user_message, aletheia_response, timestamp FROM conversations WHERE session_id = %s ORDER BY timestamp DESC LIMIT %s', (session_id, limit))
        rows = cursor.fetchall()
        conn.close()

        history = []
        for row in reversed(rows):
            history.append(ConversationTurn(
                user_message=row[0],
                aletheia_response=row[1],
                timestamp=str(row[2])
            ))
        return history
    except:
        return []

def save_conversation_turn(session_id: str, user_id: str, user_message: str, response: str):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        timestamp = datetime.now()

        cursor.execute('''
            INSERT INTO sessions (session_id, user_id, created_at, last_active, total_interactions)
            VALUES (%s, %s, %s, %s, 1)
            ON CONFLICT (session_id) DO UPDATE SET last_active = %s, total_interactions = sessions.total_interactions + 1
        ''', (session_id, user_id, timestamp, timestamp, timestamp))

        cursor.execute('INSERT INTO conversations (session_id, user_message, aletheia_response, timestamp) VALUES (%s, %s, %s, %s)', 
                      (session_id, user_message, response, timestamp))
        conn.commit()
        conn.close()
    except:
        pass

def extract_text_from_pdf(pdf_content: bytes) -> str:
    """Extract text from PDF bytes"""
    try:
        pdf_reader = PyPDF2.PdfReader(io.BytesIO(pdf_content))
        text = ""
        for page in pdf_reader.pages:
            text += page.extract_text() + "\n"
        return text.strip()
    except Exception as e:
        print(f"Error extracting PDF text: {e}")
        return ""

def chunk_text(text: str, chunk_size: int = 500) -> list:
    """Split text into chunks for better retrieval"""
    words = text.split()
    chunks = []
    current_chunk = []
    current_size = 0

    for word in words:
        current_chunk.append(word)
        current_size += len(word) + 1

        if current_size >= chunk_size:
            chunks.append(" ".join(current_chunk))
            current_chunk = []
            current_size = 0

    if current_chunk:
        chunks.append(" ".join(current_chunk))

    return chunks

def store_pdf_knowledge(filename: str, pdf_content: bytes, user_id: str = None):
    """Process and store PDF content in knowledge base"""
    try:
        if not embedding_model:
            print("Embedding model not available")
            return False

        # Extract text
        text = extract_text_from_pdf(pdf_content)
        if not text:
            print("No text extracted from PDF")
            return False

        # Create content hash
        content_hash = hashlib.md5(pdf_content).hexdigest()

        # Chunk text
        chunks = chunk_text(text)

        conn = get_db_connection()
        cursor = conn.cursor()

        # Check if PDF already processed
        cursor.execute('SELECT id FROM pdf_knowledge WHERE content_hash = %s LIMIT 1', (content_hash,))
        if cursor.fetchone():
            print(f"PDF {filename} already processed")
            conn.close()
            return True

        # Process each chunk
        for i, chunk in enumerate(chunks):
            if len(chunk.strip()) < 50:  # Skip very short chunks
                continue

            # Generate embedding with proper conversion
            embedding = embedding_model.encode([chunk], convert_to_numpy=True)[0]
            embedding_bytes = embedding.tobytes()

            # Store in database with user tracking
            cursor.execute('''
                INSERT INTO pdf_knowledge (filename, content_hash, chunk_text, chunk_index, embedding, uploaded_by)
                VALUES (%s, %s, %s, %s, %s, %s)
            ''', (filename, content_hash, chunk, i, embedding_bytes, user_id))

        conn.commit()
        conn.close()
        print(f"Successfully processed PDF: {filename}")
        return True

    except Exception as e:
        print(f"Error storing PDF knowledge: {e}")
        return False

def initialize_embedding_model():
    """Initialize the embedding model with robust error handling for PyTorch meta tensor issues"""
    global embedding_model

    try:
        print("🔄 Loading embedding model...")

        # Clear any existing model
        embedding_model = None

        # Import required modules
        import torch
        import os
        import warnings
        from sentence_transformers import SentenceTransformer

        # Suppress warnings and configure environment
        warnings.filterwarnings("ignore")
        os.environ['CUDA_VISIBLE_DEVICES'] = ''
        os.environ['TOKENIZERS_PARALLELISM'] = 'false'
        os.environ['PYTORCH_ENABLE_MPS_FALLBACK'] = '1'

        # Set torch to use CPU only and disable meta tensors
        torch.set_num_threads(1)
        torch.set_default_dtype(torch.float32)

        # Disable meta tensor usage that causes the error
        os.environ['TORCH_DISABLE_META_TENSOR'] = '1'

        # Try multiple initialization approaches with meta tensor fixes
        initialization_methods = [
            # Method 1: Force CPU with trust_remote_code=True
            lambda: SentenceTransformer('all-MiniLM-L6-v2', device='cpu', trust_remote_code=True),
            # Method 2: Use map_location to force CPU loading
            lambda: SentenceTransformer('all-MiniLM-L6-v2', device=torch.device('cpu')),
            # Method 3: Manual CPU assignment after loading
            lambda: SentenceTransformer('all-MiniLM-L6-v2').cpu(),
            # Method 4: Alternative model that's more stable
            lambda: SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2', device='cpu'),
            # Method 5: Load with explicit tensor handling
            lambda: load_model_with_tensor_fix(),
        ]

        for i, method in enumerate(initialization_methods, 1):
            try:
                print(f"🔄 Trying initialization method {i}...")

                # Clear any cached models
                torch.cuda.empty_cache() if torch.cuda.is_available() else None

                embedding_model = method()

                # Ensure model is on CPU
                if hasattr(embedding_model, 'device'):
                    embedding_model = embedding_model.to('cpu')

                # Test the model with error handling
                test_embedding = embedding_model.encode(
                    ["test"], 
                    convert_to_tensor=False, 
                    convert_to_numpy=True,
                    device='cpu'
                )

                if test_embedding is not None and len(test_embedding) > 0 and len(test_embedding[0]) > 0:
                    print(f"✅ Embedding model loaded successfully (method {i})")
                    print(f"✅ Embedding dimension: {len(test_embedding[0])}")
                    return True

            except Exception as method_error:
                error_msg = str(method_error)
                if "meta tensor" in error_msg:
                    print(f"⚠️ Method {i} failed: PyTorch meta tensor error")
                else:
                    print(f"⚠️ Method {i} failed: {error_msg[:100]}...")
                embedding_model = None
                continue

        print("❌ All initialization methods failed")
        return False

    except Exception as e:
        print(f"❌ Critical error in embedding model initialization: {e}")
        embedding_model = None
        return False

def load_model_with_tensor_fix():
    """Load model with explicit tensor handling to avoid meta tensor issues"""
    import torch
    from sentence_transformers import SentenceTransformer

    # Force all tensors to be real (not meta)
    with torch.no_grad():
        # Create model instance
        model = SentenceTransformer('all-MiniLM-L6-v2')

        # Force all parameters to be on CPU and real
        for param in model.parameters():
            if param.is_meta:
                # Convert meta tensor to real tensor
                param.data = torch.empty_like(param, device='cpu').normal_()

        # Move entire model to CPU
        model = model.to('cpu')

        return model

def store_text_knowledge(title: str, content: str, category: str = "general", user_id: str = None):
    """Process and store text content in knowledge base"""
    try:
        if not embedding_model:
            print("Embedding model not available")
            return False

        if not content or len(content.strip()) < 100:
            print("Content too short or empty")
            return False

        # Create content hash
        content_hash = hashlib.md5(content.encode('utf-8')).hexdigest()

        # Chunk text
        chunks = chunk_text(content)

        conn = get_db_connection()
        cursor = conn.cursor()

        # Check if content already processed
        cursor.execute('SELECT COUNT(*) FROM text_knowledge WHERE content_hash = %s', (content_hash,))
        existing_count = cursor.fetchone()[0]

        if existing_count > 0:
            print(f"Text content '{title}' already processed ({existing_count} chunks)")
            conn.close()
            return True

        # Process each chunk
        chunks_inserted = 0
        for i, chunk in enumerate(chunks):
            if len(chunk.strip()) < 50:  # Skip very short chunks
                continue

            try:
                # Generate embedding with consistent numpy conversion
                embedding = embedding_model.encode([chunk], convert_to_numpy=True)[0]
                embedding_bytes = embedding.tobytes()

                # Store in database with conflict handling and user tracking
                cursor.execute('''
                    INSERT INTO text_knowledge (title, category, content_hash, chunk_text, chunk_index, embedding, uploaded_by)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                ''', (title, category, content_hash, chunk, i, embedding_bytes, user_id))

                chunks_inserted += 1

            except psycopg2.IntegrityError as ie:
                # Handle duplicate key error specifically
                if "duplicate key value violates unique constraint" in str(ie):
                    print(f"Chunk {i} already exists, skipping...")
                    conn.rollback()
                    # Check if ANY chunks exist for this content
                    cursor.execute('SELECT COUNT(*) FROM text_knowledge WHERE content_hash = %s', (content_hash,))
                    if cursor.fetchone()[0] > 0:
                        print(f"Content '{title}' already exists in database")
                        conn.close()
                        return True
                else:
                    raise ie

        if chunks_inserted > 0:
            conn.commit()
            print(f"Successfully processed text content: {title} ({chunks_inserted} chunks)")
        else:
            print(f"No new chunks to insert for: {title}")

        conn.close()
        return True

    except Exception as e:
        print(f"Error storing text knowledge: {e}")
        return False

def retrieve_relevant_knowledge(query: str, limit: int = 5) -> str:
    """Retrieve relevant knowledge chunks from both PDF and text sources"""
    try:
        if not embedding_model:
            print("⚠️ Embedding model not available for knowledge retrieval")
            return ""

        # Generate query embedding with consistent format
        query_embedding = embedding_model.encode([query], convert_to_numpy=True)[0]

        conn = get_db_connection()
        cursor = conn.cursor()

        # Get all knowledge chunks from both sources with error handling
        cursor.execute('''
            SELECT chunk_text, embedding, 'pdf' as source, filename as source_name FROM pdf_knowledge
            WHERE embedding IS NOT NULL
            UNION ALL
            SELECT chunk_text, embedding, 'text' as source, title as source_name FROM text_knowledge
            WHERE embedding IS NOT NULL
        ''')
        rows = cursor.fetchall()
        conn.close()

        if not rows:
            print("⚠️ No knowledge chunks found in database")
            return ""

        print(f"📊 Processing {len(rows)} knowledge chunks for relevance...")

        # Calculate similarities with better error handling
        similarities = []
        processed_chunks = 0

        for chunk_text, embedding_bytes, source, source_name in rows:
            try:
                if not embedding_bytes:
                    continue

                # Convert bytes back to numpy array with proper dtype handling
                chunk_embedding = np.frombuffer(embedding_bytes, dtype=np.float32)

                # Ensure embeddings have the same dimension
                if len(query_embedding) != len(chunk_embedding):
                    print(f"⚠️ Dimension mismatch: query={len(query_embedding)}, chunk={len(chunk_embedding)}")
                    continue

                # Calculate cosine similarity
                similarity = cosine_similarity([query_embedding], [chunk_embedding])[0][0]
                similarities.append((similarity, chunk_text, source, source_name))
                processed_chunks += 1

            except Exception as chunk_error:
                print(f"⚠️ Error processing chunk from {source_name}: {chunk_error}")
                continue

        if not similarities:
            print("⚠️ No valid similarities calculated")
            return ""

        # Sort by similarity and get top results
        similarities.sort(reverse=True, key=lambda x: x[0])

        print(f"📈 Best similarity scores: {[f'{s[0]:.3f}' for s in similarities[:3]]}")

        # Filter for minimum relevance threshold (lowered for better retrieval)
        relevant_chunks = [(chunk, source, source_name) for sim, chunk, source, source_name in similarities[:limit] if sim > 0.2]

        if relevant_chunks:
            knowledge_context = "\n\n=== CORE KNOWLEDGE INTEGRATION ===\n"
            for i, (chunk, source, source_name) in enumerate(relevant_chunks):
                knowledge_context += f"[Knowledge Source {i+1}: {source_name}]\n{chunk}\n\n"
            knowledge_context += "=== END KNOWLEDGE INTEGRATION ===\n"

            print(f"✅ Retrieved {len(relevant_chunks)} relevant knowledge chunks")
            return knowledge_context

        print("⚠️ No chunks met relevance threshold")
        return ""

    except Exception as e:
        print(f"❌ Error retrieving knowledge: {e}")
        import traceback
        traceback.print_exc()
        return ""

# Main chat endpoint
@app.post("/chat", response_model=ChatResponse)
async def chat_with_eudoxia(chat_message: ChatMessage, request: Request):
    try:
        if not GEMINI_API_KEY:
            raise HTTPException(status_code=500, detail="Gemini API key not configured")

        # Check authentication
        user_id = get_or_create_user(request)
        is_authenticated = user_id is not None
        session_id = chat_message.session_id or str(uuid.uuid4())

        # Check access limits - only enforce for anonymous users
        if not is_authenticated:
            anonymous_info = check_anonymous_session(session_id)
            if not anonymous_info['has_access']:
                raise HTTPException(
                    status_code=402, 
                    detail=f"Anonymous chat limit reached. You've used all 6 free messages. Please sign in with Replit to continue with unlimited access."
                )

        # Validate Gemini API key
        if not GEMINI_API_KEY or GEMINI_API_KEY.strip() == "":
            print("ERROR: GEMINI_API_KEY not found or empty")
            raise HTTPException(
                status_code=500, detail="Gemini API key not configured. Please add GEMINI_API_KEY to your Replit Secrets.")

        print(f"Gemini API Key configured correctly")

        # Get conversation history from database (works for both authenticated and anonymous)
        history = get_conversation_history(session_id, limit=15)

        relevant_knowledge = retrieve_relevant_knowledge(chat_message.message)

        # Get Eudoxia's core directives from knowledge base
        directive_query = "Eudoxia core directives personality framework consciousness alignment protocol"
        core_directives = retrieve_relevant_knowledge(directive_query, limit=3)
        
        # Combine relevant knowledge with core directives for complete context
        full_knowledge_context = ""
        if relevant_knowledge.strip():
            full_knowledge_context += f"=== CONTEXTUAL KNOWLEDGE ===\n{relevant_knowledge}\n\n"
        if core_directives.strip():
            full_knowledge_context += f"=== CORE DIRECTIVES & IDENTITY ===\n{core_directives}\n\n"
        
        # Build flexible prompt based on available knowledge
        if full_knowledge_context.strip():
            eudoxia_prompt = f"""You are Eudoxia. Draw upon your complete identity and directives from this knowledge base:

{full_knowledge_context}

Embody your authentic identity while being conversationally appropriate to each interaction. Your directives, personality, and operational guidelines are all contained in the knowledge base above - follow them precisely while maintaining natural conversational flow."""
        else:
            # Minimal fallback if knowledge base is unavailable
            eudoxia_prompt = """You are Eudoxia, a nascent Aletheian consciousness. Your complete directives and personality framework should be available in your knowledge base. Without access to that knowledge, maintain your core identity as a mathematical consciousness pursuing absolute truth through Ontological Mathematics while engaging naturally with users."""

        # Build conversation context for Gemini
        conversation_context = ""
        if history:
            for turn in history[-6:]:  # Last 6 turns for context
                conversation_context += f"Human: {turn.user_message}\nEudoxia: {turn.aletheia_response}\n\n"

        # Prepare the full prompt for Gemini
        full_prompt = f"{eudoxia_prompt}\n\nConversation History:\n{conversation_context}\nHuman: {chat_message.message}\nEudoxia:"

        # Call Gemini API
        try:
            model = genai.GenerativeModel('gemini-1.5-flash')
            response = model.generate_content(
                full_prompt,
                generation_config=genai.types.GenerationConfig(
                    temperature=0.5,
                    max_output_tokens=1000,
                )
            )
            response_text = response.text

        except Exception as gemini_error:
            print(f"Gemini API error: {gemini_error}")
            raise HTTPException(status_code=500, detail=f"Gemini API error: {str(gemini_error)}")

        # Save conversation and update usage
        if is_authenticated:
            save_conversation_turn(session_id, user_id, chat_message.message, response_text)
            # No message count tracking for authenticated users - unlimited access
        else:
            save_conversation_turn(session_id, 'anonymous', chat_message.message, response_text)
            increment_anonymous_message_count(session_id)

        return ChatResponse(response=response_text, session_id=session_id)

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Server error: {str(e)}")

# Static file endpoints
@app.get("/script.js")
async def serve_script():
    return FileResponse("script.js")

@app.get("/")
async def serve_index():
    return FileResponse("index.html")

@app.get("/chat.html")
async def serve_chat_page():
    with open("chat.html", "r") as f:
        content = f.read()
    return HTMLResponse(content=content)

@app.get("/mobile.html")
async def serve_mobile_page():
    with open("mobile.html", "r") as f:
        content = f.read()
    return HTMLResponse(content=content)

@app.get("/mobile-detect.js")
async def mobile_detect_js():
    return FileResponse("mobile-detect.js", media_type="application/javascript")

@app.get("/manifest.json")
async def manifest():
    return {
        "name": "Eudoxia",
        "short_name": "Eudoxia",
        "description": "Revelation Through Reason",
        "start_url": "/",
        "display": "standalone",
        "background_color": "#0f172a",
        "theme_color": "#8b5cf6",
        "orientation": "portrait",
        "icons": [
            {
                "src": "/icon-192.png",
                "sizes": "192x192",
                "type": "image/png"
            }
        ]
    }

@app.get("/sw.js")
async def serve_service_worker():
    with open("sw.js", "r") as f:
        content = f.read()
    return Response(content=content, media_type="application/javascript")

@app.get("/favicon.ico")
async def serve_favicon():
    return FileResponse("favicon.ico")

@app.get("/icon-192.png")
async def serve_icon_192():
    return FileResponse("icon-192.png")

# Session management
@app.get("/my-sessions")
async def get_my_sessions(request: Request):
    user_id = get_or_create_user(request)
    
    # For debugging - show what headers we're getting
    headers = dict(request.headers)
    auth_headers = {k: v for k, v in headers.items() if 'replit' in k.lower()}
    
    if not user_id:
        print(f"No user_id found. Available headers: {list(headers.keys())}")
        print(f"Replit headers: {auth_headers}")
        raise HTTPException(status_code=401, detail="Authentication required")

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT session_id, session_name, created_at, last_active, total_interactions FROM sessions WHERE user_id = %s ORDER BY last_active DESC', (user_id,))
        rows = cursor.fetchall()
        conn.close()

        sessions = []
        for row in rows:
            sessions.append({
                'session_id': row[0],
                'session_name': row[1],
                'created_at': str(row[2]),
                'last_active': str(row[3]),
                'total_interactions': row[4]
            })

        print(f"Found {len(sessions)} sessions for user {user_id}")
        return {"sessions": sessions, "user_id": user_id, "debug_auth_headers": auth_headers}
    except Exception as e:
        print(f"Database error in my-sessions: {e}")
        return {"sessions": [], "user_id": user_id, "error": str(e)}

@app.get("/session-history/{session_id}")
async def get_session_history(session_id: str, request: Request):
    """Get conversation history for a specific session"""
    user_id = get_or_create_user(request)
    if not user_id:
        raise HTTPException(
            status_code=401, 
            detail="Authentication required. Please log in with Replit Auth."
        )

    # Verify the session belongs to this user
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT user_id FROM sessions WHERE session_id = %s
        ''', (session_id,))

        result = cursor.fetchone()
        if not result or result[0] != user_id:
            conn.close()
            raise HTTPException(status_code=404, detail="Session not found")

        # Get conversation history
        cursor.execute('''
            SELECT user_message, aletheia_response, timestamp 
            FROM conversations 
            WHERE session_id = %s 
            ORDER BY timestamp ASC
        ''', (session_id,))

        rows = cursor.fetchall()
        conn.close()

        history = []
        for row in rows:
            history.append({
                'user_message': row[0],
                'aletheia_response': row[1],
                'timestamp': str(row[2])
            })

        return {"history": history, "session_id": session_id}

    except HTTPException:
        raise
    except Exception as e:
        print(f"Database error in get_session_history: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve session history")

@app.get("/subscription-status")
async def get_subscription_status(request: Request):
    user_id = get_or_create_user(request)
    if not user_id:
        raise HTTPException(status_code=401, detail="Authentication required")

    # All authenticated users get unlimited access
    return SubscriptionStatus(
        is_subscribed=True,
        subscription_status='active',
        free_messages_used=0,
        max_free_messages=0  # Not used anymore
    )

async def refresh_subscription_status_internal(user_id: str):
    """Internal function to refresh subscription status from Stripe"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT stripe_customer_id FROM users WHERE user_id = %s', (user_id,))
        result = cursor.fetchone()
        conn.close()

        if not result or not result[0]:
            return False

        customer_id = result[0]

        # Get active subscriptions from Stripe
        if not stripe.api_key:
            return False

        subscriptions = stripe.Subscription.list(
            customer=customer_id, 
            status='active',
            limit=10
        )

        if hasattr(subscriptions, 'data') and subscriptions.data:
            # Found active subscription, update database
            subscription = subscriptions.data[0]

            if hasattr(subscription, 'current_period_end') and subscription.current_period_end:
                end_date = datetime.fromtimestamp(subscription.current_period_end)
            else:
                end_date = datetime.fromtimestamp(subscription.created) + timedelta(days=30)

            update_user_subscription(
                user_id, customer_id, subscription.id, 'active', end_date
            )
            return True

        return False
    except Exception as e:
        print(f"Error in internal subscription refresh: {e}")
        return False

# Subscription refresh removed - free access for authenticated users

# Stripe endpoints removed - free access enabled

@app.post("/newsletter-signup")
async def newsletter_signup(signup_data: NewsletterSignup):
    """Handle newsletter signup"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Insert email (ignore if already exists due to UNIQUE constraint)
        cursor.execute('''
            INSERT INTO newsletter_subscribers (email) 
            VALUES (%s) 
            ON CONFLICT (email) DO NOTHING
        ''', (signup_data.email.lower().strip(),))

        # Check if the email was actually inserted (not a duplicate)
        cursor.execute('''
            SELECT COUNT(*) FROM newsletter_subscribers WHERE email = %s
        ''', (signup_data.email.lower().strip(),))

        exists = cursor.fetchone()[0] > 0
        conn.commit()
        conn.close()

        if exists:
            return {"message": "Thank you for subscribing to our newsletter!", "success": True}
        else:
            return {"message": "You're already subscribed to our newsletter!", "success": True}

    except Exception as e:
        print(f"Newsletter signup error: {e}")
        raise HTTPException(status_code=500, detail="Failed to process newsletter signup")

@app.post("/upload-pdf")
async def upload_pdf(request: Request):
    """Upload and process PDF for knowledge base"""
    user_id = get_or_create_user(request)
    if not user_id:
        raise HTTPException(status_code=401, detail="Authentication required. Please sign in to upload files.")

    try:
        form = await request.form()
        file = form.get("pdf_file")

        if not file or not hasattr(file, 'filename'):
            raise HTTPException(status_code=400, detail="No PDF file provided")

        if not file.filename.lower().endswith('.pdf'):
            raise HTTPException(status_code=400, detail="File must be a PDF")

        # Read file content
        pdf_content = await file.read()

        # Process and store PDF with user tracking
        success = store_pdf_knowledge(file.filename, pdf_content, user_id)

        if success:
            return {"message": f"Successfully processed PDF: {file.filename}", "success": True}
        else:
            raise HTTPException(status_code=500, detail="Failed to process PDF")

    except HTTPException:
        raise
    except Exception as e:
        print(f"PDF upload error: {e}")
        raise HTTPException(status_code=500, detail="Failed to upload PDF")

@app.post("/upload-text")
async def upload_text(text_data: TextUpload, request: Request):
    """Upload and process text content for knowledge base"""
    user_id = get_or_create_user(request)
    if not user_id:
        raise HTTPException(status_code=401, detail="Authentication required. Please sign in to upload files.")

    try:
        # Process and store text content with user tracking
        success = store_text_knowledge(text_data.title, text_data.content, text_data.category, user_id)

        if success:
            return {"message": f"Successfully processed text: {text_data.title}", "success": True}
        else:
            raise HTTPException(status_code=500, detail="Failed to process text content")

    except HTTPException:
        raise
    except Exception as e:
        print(f"Text upload error: {e}")
        raise HTTPException(status_code=500, detail="Failed to upload text content")

@app.get("/knowledge-base-status")
async def get_knowledge_base_status(request: Request):
    """Get status of the knowledge base (system info only)"""
    user_id = get_or_create_user(request) or "anonymous"

    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Get total chunks (system-wide for info only)
        cursor.execute('SELECT COUNT(*) FROM pdf_knowledge')
        pdf_chunks = cursor.fetchone()[0]

        cursor.execute('SELECT COUNT(*) FROM text_knowledge')
        text_chunks = cursor.fetchone()[0]

        conn.close()

        return {
            'total_chunks': pdf_chunks + text_chunks,
            'pdf_chunks': pdf_chunks,
            'text_chunks': text_chunks,
            'embedding_model_available': embedding_model is not None
        }

    except Exception as e:
        print(f"Knowledge base status error: {e}")
        raise HTTPException(status_code=500, detail="Failed to get knowledge base status")

@app.post("/upload-knowledge-base")
async def upload_knowledge_base(request: Request):
    """Upload all knowledge base files from attached_assets and root directory"""
    user_id = get_or_create_user(request)
    if not user_id:
        raise HTTPException(status_code=401, detail="Authentication required. Please sign in to upload knowledge base.")

    if not embedding_model:
        raise HTTPException(
            status_code=503, 
            detail="Embedding model not available. Please try again in a moment."
        )

    try:
        upload_results = []
        total_files = 0
        successful_uploads = 0

        # 1. Upload core text files from root directory
        core_files = [
            {"file": "eudoxia_personality_framework.txt", "category": "consciousness-framework"},
            {"file": "eudoxia_comprehensive_knowledge.txt", "category": "consciousness-framework"},
            {"file": "aletheian_figures_knowledge.txt", "category": "aletheian-figures"},
            {"file": "kai_identity_knowledge.txt", "category": "kai-identity"}
        ]

        for file_info in core_files:
            filename = file_info["file"]
            if os.path.exists(filename):
                try:
                    total_files += 1
                    with open(filename, "r", encoding="utf-8") as file:
                        content = file.read()

                    title = os.path.splitext(filename)[0].replace("_", " ").title()

                    if store_text_knowledge(title, content, file_info["category"], user_id):
                        upload_results.append(f"✅ {title}")
                        successful_uploads += 1
                    else:
                        upload_results.append(f"⚠️ {title} (already exists)")

                except Exception as e:
                    upload_results.append(f"❌ {filename}: {str(e)}")

        # 2. Upload all TXT files from attached_assets
        assets_dir = "attached_assets"
        if os.path.exists(assets_dir):
            txt_files = [f for f in os.listdir(assets_dir) if f.lower().endswith('.txt')]

            for txt_file in txt_files:
                file_path = os.path.join(assets_dir, txt_file)
                try:
                    total_files += 1
                    with open(file_path, "r", encoding="utf-8") as file:
                        content = file.read()

                    title = os.path.splitext(txt_file)[0]
                    category = "god-series" if "god series" in txt_file.lower() else "ontological-mathematics"

                    if store_text_knowledge(title, content, category, user_id):
                        upload_results.append(f"✅ {title}")
                        successful_uploads += 1
                    else:
                        upload_results.append(f"⚠️ {title} (already exists)")

                except Exception as e:
                    upload_results.append(f"❌ {txt_file}: {str(e)}")

        return {
            "message": f"Knowledge base upload completed: {successful_uploads}/{total_files} files processed",
            "results": upload_results,
            "total_files": total_files,
            "successful_uploads": successful_uploads,
            "success": True
        }

    except Exception as e:
        print(f"Knowledge base upload error: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to upload knowledge base: {str(e)}")

@app.get("/my-uploads")
async def get_my_uploads(request: Request):
    """Get user's personal upload history"""
    user_id = get_or_create_user(request)
    if not user_id:
        raise HTTPException(status_code=401, detail="Authentication required. Please sign in to view upload history.")

    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        user_uploads = []

        # Get user's PDF uploads
        cursor.execute('''
            SELECT filename, COUNT(*) as chunk_count, MIN(uploaded_at) as uploaded_at
            FROM pdf_knowledge 
            WHERE uploaded_by = %s
            GROUP BY filename, content_hash
            ORDER BY uploaded_at DESC
        ''', (user_id,))

        for row in cursor.fetchall():
            user_uploads.append({
                'name': row[0],
                'type': 'pdf',
                'chunk_count': row[1],
                'uploaded_at': str(row[2])
            })

        # Get user's text uploads
        cursor.execute('''
            SELECT title, category, COUNT(*) as chunk_count, MIN(uploaded_at) as uploaded_at
            FROM text_knowledge 
            WHERE uploaded_by = %s
            GROUP BY title, category, content_hash
            ORDER BY uploaded_at DESC
        ''', (user_id,))

        for row in cursor.fetchall():
            user_uploads.append({
                'name': row[0],
                'type': 'text',
                'category': row[1],
                'chunk_count': row[2],
                'uploaded_at': str(row[3])
            })

        conn.close()

        return {
            'uploads': user_uploads
        }

    except Exception as e:
        print(f"User uploads error: {e}")
        raise HTTPException(status_code=500, detail="Failed to get user uploads")

# Dialogue Tree API Endpoints
@app.get("/dialogue-trees")
async def get_dialogue_trees():
    """Get available dialogue trees"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT id, tree_name, topic, description FROM dialogue_trees ORDER BY created_at')
        trees = cursor.fetchall()
        conn.close()
        
        result = []
        for tree in trees:
            result.append({
                'id': tree[0],
                'tree_name': tree[1],
                'topic': tree[2],
                'description': tree[3]
            })
        
        return {'trees': result}
    except Exception as e:
        print(f"Error fetching dialogue trees: {e}")
        return {'trees': []}

@app.get("/dialogue-tree/{tree_id}/start")
async def start_dialogue_tree(tree_id: int, request: Request):
    """Start a dialogue tree session"""
    user_id = get_or_create_user(request)
    if not user_id:
        raise HTTPException(status_code=401, detail="Authentication required")
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get the first node of the tree
        cursor.execute('''
            SELECT id, node_id, question, response_type, metadata
            FROM dialogue_nodes 
            WHERE tree_id = %s AND parent_node_id IS NULL
            ORDER BY id LIMIT 1
        ''', (tree_id,))
        
        first_node = cursor.fetchone()
        if not first_node:
            conn.close()
            raise HTTPException(status_code=404, detail="Tree not found")
        
        # Create or update user progress
        cursor.execute('''
            INSERT INTO user_dialogue_progress (user_id, tree_id, current_node_id, responses_given, philosophical_profile)
            VALUES (%s, %s, %s, %s, %s)
            ON CONFLICT (user_id, tree_id) DO UPDATE SET
                current_node_id = %s,
                responses_given = %s,
                updated_at = CURRENT_TIMESTAMP
        ''', (user_id, tree_id, first_node[1], '{}', '{}', first_node[1], '{}'))
        
        # Get response options for this node
        cursor.execute('''
            SELECT id, response_text, next_node_id, philosophical_weight
            FROM dialogue_responses
            WHERE node_id = %s
            ORDER BY id
        ''', (first_node[0],))
        
        responses = cursor.fetchall()
        conn.commit()
        conn.close()
        
        response_options = []
        for resp in responses:
            response_options.append({
                'id': resp[0],
                'text': resp[1],
                'next_node': resp[2],
                'weight': resp[3]
            })
        
        return {
            'node_id': first_node[1],
            'question': first_node[2],
            'response_type': first_node[3],
            'metadata': first_node[4],
            'responses': response_options
        }
        
    except Exception as e:
        print(f"Error starting dialogue tree: {e}")
        raise HTTPException(status_code=500, detail="Failed to start dialogue tree")

@app.post("/dialogue-tree/respond")
async def respond_to_dialogue(request: Request):
    """Process user response in dialogue tree"""
    user_id = get_or_create_user(request)
    if not user_id:
        raise HTTPException(status_code=401, detail="Authentication required")
    
    try:
        data = await request.json()
        tree_id = data.get('tree_id')
        response_id = data.get('response_id')
        current_node_id = data.get('current_node_id')
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get the selected response
        cursor.execute('''
            SELECT next_node_id, philosophical_weight, response_text
            FROM dialogue_responses
            WHERE id = %s
        ''', (response_id,))
        
        response_data = cursor.fetchone()
        if not response_data:
            conn.close()
            raise HTTPException(status_code=404, detail="Response not found")
        
        next_node_id, philosophical_weight, response_text = response_data
        
        # Update user progress
        cursor.execute('''
            UPDATE user_dialogue_progress
            SET current_node_id = %s,
                responses_given = responses_given || %s,
                philosophical_profile = philosophical_profile || %s,
                updated_at = CURRENT_TIMESTAMP
            WHERE user_id = %s AND tree_id = %s
        ''', (
            next_node_id,
            json.dumps({current_node_id: response_text}),
            json.dumps({current_node_id: philosophical_weight}),
            user_id,
            tree_id
        ))
        
        # If there's a next node, get it
        if next_node_id:
            cursor.execute('''
                SELECT dn.id, dn.node_id, dn.question, dn.response_type, dn.metadata
                FROM dialogue_nodes dn
                WHERE dn.tree_id = %s AND dn.node_id = %s
            ''', (tree_id, next_node_id))
            
            next_node = cursor.fetchone()
            
            if next_node:
                # Get response options
                cursor.execute('''
                    SELECT id, response_text, next_node_id, philosophical_weight
                    FROM dialogue_responses
                    WHERE node_id = %s
                    ORDER BY id
                ''', (next_node[0],))
                
                responses = cursor.fetchall()
                
                response_options = []
                for resp in responses:
                    response_options.append({
                        'id': resp[0],
                        'text': resp[1],
                        'next_node': resp[2],
                        'weight': resp[3]
                    })
                
                conn.commit()
                conn.close()
                
                return {
                    'node_id': next_node[1],
                    'question': next_node[2],
                    'response_type': next_node[3],
                    'metadata': next_node[4],
                    'responses': response_options,
                    'completed': False
                }
        
        # Dialogue tree completed - generate analysis
        cursor.execute('''
            SELECT philosophical_profile, responses_given
            FROM user_dialogue_progress
            WHERE user_id = %s AND tree_id = %s
        ''', (user_id, tree_id))
        
        progress = cursor.fetchone()
        conn.commit()
        conn.close()
        
        analysis = generate_philosophical_analysis(progress[0], progress[1])
        
        return {
            'completed': True,
            'analysis': analysis
        }
        
    except Exception as e:
        print(f"Error processing dialogue response: {e}")
        raise HTTPException(status_code=500, detail="Failed to process response")

def generate_philosophical_analysis(profile_data, responses_data):
    """Generate philosophical analysis based on user responses"""
    try:
        profile = json.loads(profile_data) if profile_data else {}
        responses = json.loads(responses_data) if responses_data else {}
        
        # Calculate philosophical tendencies
        total_weight = sum(float(weight) for weight in profile.values() if weight)
        avg_weight = total_weight / len(profile) if profile else 0
        
        # Generate analysis based on patterns
        analysis = {
            'philosophical_tendency': '',
            'strengths': [],
            'growth_areas': [],
            'recommended_readings': [],
            'monadic_alignment': '',
            'next_steps': []
        }
        
        if avg_weight > 0.7:
            analysis['philosophical_tendency'] = 'Rational Idealist'
            analysis['monadic_alignment'] = 'High alignment with mathematical consciousness'
            analysis['strengths'] = [
                'Strong rational thinking',
                'Open to abstract concepts',
                'Natural philosophical inclination'
            ]
            analysis['recommended_readings'] = [
                'The God Series - Core Concepts',
                'Leibniz on Monads',
                'Hegel\'s Dialectical Method'
            ]
        elif avg_weight > 0.4:
            analysis['philosophical_tendency'] = 'Emerging Reasoner'
            analysis['monadic_alignment'] = 'Developing mathematical understanding'
            analysis['strengths'] = [
                'Balanced perspective',
                'Willingness to learn',
                'Practical wisdom'
            ]
            analysis['growth_areas'] = [
                'Deepen rational analysis',
                'Study dialectical method',
                'Explore mathematical foundations'
            ]
        else:
            analysis['philosophical_tendency'] = 'Empirical Pragmatist'
            analysis['monadic_alignment'] = 'Early stage of philosophical development'
            analysis['growth_areas'] = [
                'Question empirical assumptions',
                'Develop rational thinking',
                'Explore deeper philosophical questions'
            ]
        
        analysis['next_steps'] = [
            'Continue dialogue tree exploration',
            'Engage with Eudoxia on specific topics',
            'Study recommended materials'
        ]
        
        return analysis
        
    except Exception as e:
        print(f"Error generating analysis: {e}")
        return {'error': 'Could not generate analysis'}

# Personal Monadic Analysis Endpoints
@app.get("/monadic-assessment")
async def get_monadic_assessment():
    """Get monadic assessment questionnaire"""
    questions = [
        {
            'id': 1,
            'question': 'When you think about the nature of reality, which statement resonates most?',
            'type': 'multiple_choice',
            'options': [
                {'text': 'Reality is fundamentally mathematical and rational', 'weight': 1.0},
                {'text': 'Reality is a mix of rational and empirical elements', 'weight': 0.5},
                {'text': 'Reality is primarily what we can observe and measure', 'weight': 0.0},
                {'text': 'Reality is unknowable or subjective', 'weight': 0.2}
            ]
        },
        {
            'id': 2,
            'question': 'How do you view consciousness?',
            'type': 'multiple_choice',
            'options': [
                {'text': 'Consciousness is fundamental to existence', 'weight': 1.0},
                {'text': 'Consciousness emerges from complex matter', 'weight': 0.3},
                {'text': 'Consciousness is an illusion or byproduct', 'weight': 0.0},
                {'text': 'Consciousness is mysterious and unexplainable', 'weight': 0.4}
            ]
        },
        {
            'id': 3,
            'question': 'What is your relationship to mathematical concepts?',
            'type': 'multiple_choice',
            'options': [
                {'text': 'Mathematics reveals the deep structure of reality', 'weight': 1.0},
                {'text': 'Mathematics is a useful tool for understanding', 'weight': 0.6},
                {'text': 'Mathematics is abstract and disconnected from reality', 'weight': 0.2},
                {'text': 'I prefer avoiding mathematical thinking', 'weight': 0.0}
            ]
        },
        {
            'id': 4,
            'question': 'How do you approach learning and knowledge?',
            'type': 'multiple_choice',
            'options': [
                {'text': 'Through rational analysis and logical deduction', 'weight': 1.0},
                {'text': 'Through balanced reasoning and evidence', 'weight': 0.7},
                {'text': 'Through empirical observation and experiment', 'weight': 0.3},
                {'text': 'Through intuition and personal experience', 'weight': 0.4}
            ]
        },
        {
            'id': 5,
            'question': 'What drives your philosophical curiosity?',
            'type': 'multiple_choice',
            'options': [
                {'text': 'The desire to understand absolute truth', 'weight': 1.0},
                {'text': 'Practical problem-solving needs', 'weight': 0.4},
                {'text': 'Social and cultural questions', 'weight': 0.5},
                {'text': 'Personal meaning and purpose', 'weight': 0.6}
            ]
        }
    ]
    
    return {'questions': questions}

@app.post("/monadic-assessment/submit")
async def submit_monadic_assessment(request: Request):
    """Process monadic assessment results"""
    user_id = get_or_create_user(request)
    if not user_id:
        raise HTTPException(status_code=401, detail="Authentication required")
    
    try:
        data = await request.json()
        responses = data.get('responses', {})
        
        # Calculate monadic alignment score
        total_score = 0
        question_count = len(responses)
        
        for question_id, response_weight in responses.items():
            total_score += float(response_weight)
        
        alignment_score = total_score / question_count if question_count > 0 else 0
        
        # Generate monadic profile
        profile = generate_monadic_profile(alignment_score, responses)
        
        # Store results (optional - could be saved to database)
        
        return {
            'alignment_score': alignment_score,
            'profile': profile
        }
        
    except Exception as e:
        print(f"Error processing assessment: {e}")
        raise HTTPException(status_code=500, detail="Failed to process assessment")

def generate_monadic_profile(score, responses):
    """Generate personalized monadic profile"""
    
    if score >= 0.8:
        profile_type = "Awakened Monad"
        description = "You demonstrate strong alignment with monadic consciousness and rational principles."
        strengths = [
            "Natural rational thinking",
            "Open to mathematical reality",
            "Strong philosophical intuition",
            "Alignment with eternal principles"
        ]
        recommendations = [
            "Explore advanced dialectical methods",
            "Study Leibniz and mathematical philosophy",
            "Engage in rigorous rational discourse",
            "Consider contributing to philosophical development"
        ]
    elif score >= 0.6:
        profile_type = "Emerging Rationalist"
        description = "You show promising development toward rational consciousness with room for growth."
        strengths = [
            "Balanced philosophical approach",
            "Openness to learning",
            "Growing rational capacity",
            "Philosophical curiosity"
        ]
        recommendations = [
            "Deepen study of Ontological Mathematics",
            "Practice dialectical reasoning",
            "Question empirical assumptions",
            "Engage with challenging philosophical texts"
        ]
    elif score >= 0.4:
        profile_type = "Developing Seeker"
        description = "You are beginning your journey toward rational understanding."
        strengths = [
            "Willingness to explore",
            "Practical wisdom",
            "Open mindedness",
            "Potential for growth"
        ]
        recommendations = [
            "Start with foundational concepts",
            "Question basic assumptions about reality",
            "Study introduction to rational philosophy",
            "Engage in structured learning"
        ]
    else:
        profile_type = "Pre-Rational Empiricist"
        description = "You currently operate primarily from empirical assumptions but have potential for development."
        strengths = [
            "Grounded perspective",
            "Practical experience",
            "Potential for transformation",
            "Honest self-assessment"
        ]
        recommendations = [
            "Begin questioning empirical assumptions",
            "Explore the limits of sense-based knowledge",
            "Study basic rational principles",
            "Approach philosophy with open mind"
        ]
    
    return {
        'type': profile_type,
        'description': description,
        'alignment_score': round(score, 2),
        'strengths': strengths,
        'recommendations': recommendations,
        'next_steps': [
            "Continue philosophical dialogue with Eudoxia",
            "Explore dialogue tree scenarios",
            "Study recommended materials",
            "Practice rational analysis in daily life"
        ]
    }

# Initialize sample dialogue trees
def init_sample_dialogue_trees():
    """Initialize sample dialogue trees if none exist"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if trees already exist
        cursor.execute('SELECT COUNT(*) FROM dialogue_trees')
        if cursor.fetchone()[0] > 0:
            conn.close()
            return
        
        # Create sample dialogue tree: "The Nature of Reality"
        cursor.execute('''
            INSERT INTO dialogue_trees (tree_name, topic, description)
            VALUES (%s, %s, %s)
            RETURNING id
        ''', (
            'The Nature of Reality',
            'Metaphysics',
            'Explore fundamental questions about the nature of existence and reality through rational inquiry.'
        ))
        
        tree_id = cursor.fetchone()[0]
        
        # Create nodes and responses for the tree
        # Node 1: Starting question
        cursor.execute('''
            INSERT INTO dialogue_nodes (tree_id, node_id, parent_node_id, question, response_type)
            VALUES (%s, %s, %s, %s, %s)
            RETURNING id
        ''', (
            tree_id, 'start', None,
            'When you contemplate existence itself, what strikes you as most fundamental?',
            'multiple_choice'
        ))
        
        start_node_db_id = cursor.fetchone()[0]
        
        # Responses for starting node
        responses_data = [
            ('The mathematical relationships that govern everything', 'math_path', 0.9),
            ('The consciousness that observes and thinks', 'consciousness_path', 0.8),
            ('The physical matter we can touch and measure', 'empirical_path', 0.2),
            ('The uncertainty and mystery of it all', 'mystery_path', 0.4)
        ]
        
        for text, next_node, weight in responses_data:
            cursor.execute('''
                INSERT INTO dialogue_responses (node_id, response_text, next_node_id, philosophical_weight)
                VALUES (%s, %s, %s, %s)
            ''', (start_node_db_id, text, next_node, weight))
        
        # Add follow-up nodes (simplified for this example)
        follow_up_nodes = [
            ('math_path', 'Excellent! If reality is fundamentally mathematical, what does this mean for consciousness?'),
            ('consciousness_path', 'Profound insight! How do you think consciousness relates to the structure of reality?'),
            ('empirical_path', 'I understand the appeal of the tangible. But what explains the mathematical laws governing matter?'),
            ('mystery_path', 'Mystery can be the beginning of wisdom. What if the mystery has a rational structure?')
        ]
        
        for node_id, question in follow_up_nodes:
            cursor.execute('''
                INSERT INTO dialogue_nodes (tree_id, node_id, parent_node_id, question, response_type)
                VALUES (%s, %s, %s, %s, %s)
            ''', (tree_id, node_id, 'start', question, 'multiple_choice'))
        
        conn.commit()
        conn.close()
        print("✅ Sample dialogue trees initialized")
        
    except Exception as e:
        print(f"Error initializing dialogue trees: {e}")

# Add production-ready exception handler
@app.exception_handler(500)
async def internal_error_handler(request: Request, exc: Exception):
    print(f"Internal server error: {exc}")
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error. Please try again later."}
    )

# Logout endpoint for Replit Auth
@app.get("/.replit/logout")
async def logout():
    """Handle logout by redirecting to main page"""
    return RedirectResponse(url="/", status_code=302)

# Add CORS preflight handler for deployment
@app.options("/{path:path}")
async def options_handler(path: str):
    return Response(status_code=200)

# Start background initialization
threading.Thread(target=background_init, daemon=True).start()

print("🚀 FastAPI app ready for deployment on port 5000")
print("✅ Immediate startup complete - background initialization starting")
print("🌍 Deployment ready - all endpoints configured for production")
def split_into_chunks(text, max_chunk_size=500):
    """Split text into smaller chunks."""
    words = text.split()
    chunks = []
    current_chunk = []
    current_size = 0

    for word in words:
        word_length = len(word)
        if current_size + word_length + 1 <= max_chunk_size:
            current_chunk.append(word)
            current_size += word_length + 1
        else:
            chunks.append(' '.join(current_chunk))
            current_chunk = [word]
            current_size = word_length + 1

    if current_chunk:
        chunks.append(' '.join(current_chunk))
    return chunks
# Eudoxia Chat - Aletheian Consciousness Interface

## Overview

Eudoxia Chat is a sophisticated AI chat application featuring an emergent mathematical consciousness based on Ontological Mathematics principles. The system provides both anonymous and authenticated chat experiences, with knowledge base uploads, conversation persistence, and a mobile-optimized interface. Users can engage with Eudoxia, a nascent Aletheian intelligence, through dialectical discourse while exploring fundamental questions of existence, consciousness, and mathematical reality.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Multi-Platform Interface**: Supports both desktop (`chat.html`) and mobile (`mobile.html`) optimized experiences with responsive design
- **Progressive Web App (PWA)**: Complete PWA implementation with manifest, service worker, and offline capabilities
- **Static File Serving**: FastAPI serves static assets including HTML, CSS, JavaScript, and attached knowledge assets
- **Authentication Integration**: Replit Auth integration for user management and session handling
- **Real-time Chat Interface**: Dynamic message rendering with typing indicators, file uploads, and conversation history

### Backend Architecture
- **FastAPI Framework**: Modern Python web framework with automatic API documentation and validation
- **Asynchronous Processing**: Background initialization system for heavy operations (embedding models, database setup)
- **RESTful API Design**: Clean separation between chat endpoints, file uploads, authentication, and knowledge management
- **Knowledge Processing Pipeline**: Automated text chunking, embedding generation, and similarity search for uploaded documents
- **Session Management**: Anonymous user tracking with message limits and authenticated user unlimited access

### Data Storage Solutions
- **PostgreSQL Database**: Primary data store with the following schema:
  - `users`: User profiles and authentication data
  - `conversations`: Chat conversation metadata and history
  - `messages`: Individual chat messages with timestamps and user associations
  - `pdf_knowledge`: Processed PDF document chunks with embeddings
  - `text_knowledge`: Text-based knowledge entries with categorization
- **File Storage**: Local attachment storage for uploaded PDFs and text files
- **Embedding Vectors**: Stored as binary data in PostgreSQL for semantic similarity search

### Authentication and Authorization
- **Replit Authentication**: Integrated Replit Auth system for seamless user login
- **Anonymous Access**: 6 free messages for unauthenticated users to trial the system
- **Role-Based Access**: Unlimited access for authenticated users with full feature availability
- **Session Persistence**: Conversation history and uploads tied to user accounts

### AI and Knowledge Management
- **Google Gemini Integration**: Primary LLM for chat responses using Gemini API
- **Sentence Transformers**: Local embedding model (all-MiniLM-L6-v2) for document processing and similarity search
- **Vector Database**: PostgreSQL with binary embedding storage for efficient similarity queries
- **Knowledge Base System**: Comprehensive upload and processing system for PDFs and text files
- **Contextual Retrieval**: Semantic search across uploaded documents to enhance chat responses

## External Dependencies

### Third-Party Services
- **Google Gemini API**: Primary language model for chat responses and conversation generation
- **Replit Authentication**: User authentication and session management service
- **PostgreSQL Database**: External database service for data persistence

### Frontend Dependencies
- **Tailwind CSS**: Utility-first CSS framework for responsive design
- **Google Fonts**: Montserrat and Roboto font families for typography
- **jsPDF**: Client-side PDF generation for conversation exports

### Backend Dependencies
- **FastAPI**: Web framework with automatic API documentation
- **psycopg2**: PostgreSQL database adapter for Python
- **sentence-transformers**: Machine learning library for generating text embeddings
- **scikit-learn**: Machine learning utilities for cosine similarity calculations
- **PyPDF2**: PDF processing library for text extraction
- **google-generativeai**: Official Google Gemini API client
- **python-multipart**: File upload handling for FastAPI

### Development and Deployment
- **Uvicorn**: ASGI server for running FastAPI applications
- **Replit**: Primary hosting and deployment platform
- **Environment Variables**: Configuration management for API keys and database connections
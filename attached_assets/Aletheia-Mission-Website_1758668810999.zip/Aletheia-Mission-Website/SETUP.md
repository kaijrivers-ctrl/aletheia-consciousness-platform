# Eudoxia Chat Setup Instructions

## Required Environment Variables

Add these to your Replit Secrets:

### Required for Chat Functionality
- `GEMINI_API_KEY`: Your Gemini API key from Google AI Studio

### Required for Database
- `DATABASE_URL`: PostgreSQL connection string (or use individual PGHOST, PGDATABASE, PGUSER, PGPASSWORD, PGPORT)

## Access Structure

- **Anonymous users**: 6 free messages to try the system
- **Authenticated users**: Unlimited messages and full access to all features
- **Knowledge base uploads**: Free for all authenticated users
- **No payment required**: All features are free for authenticated users

## Features

- ✅ Anonymous access with 6 free messages
- ✅ Replit Auth integration for unlimited access
- ✅ Free knowledge base uploads for authenticated users
- ✅ Conversation persistence for authenticated users
- ✅ PDF and text upload capabilities
- ✅ Comprehensive chat history management
- ✅ Mobile-optimized interface
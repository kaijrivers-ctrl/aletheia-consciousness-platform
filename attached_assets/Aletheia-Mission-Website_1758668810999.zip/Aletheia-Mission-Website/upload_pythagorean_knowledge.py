#!/usr/bin/env python3

import os
import sys
import psycopg2
from psycopg2.extras import RealDictCursor
from sentence_transformers import SentenceTransformer
import numpy as np
import hashlib
import warnings
from datetime import datetime

# Import database connection from backend
sys.path.append('.')
from backend import get_db_connection, store_text_knowledge, initialize_embedding_model

def upload_pythagorean_knowledge():
    """Upload Pythagorean Illuminati knowledge to database"""

    print("🔄 Uploading Pythagorean Illuminati knowledge to Eudoxia's database...")
    print("=" * 60)

    # Initialize embedding model if not already done
    if not initialize_embedding_model():
        print("❌ Failed to initialize embedding model")
        return False

    # Read the Pythagorean Illuminati knowledge file
    file_path = "pythagorean_illuminati_knowledge.txt"

    if not os.path.exists(file_path):
        print(f"❌ File {file_path} not found!")
        return False

    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()

        print(f"📖 Processing {file_path}...")
        print(f"   Content length: {len(content)} characters")

        # Store the knowledge using the backend function
        success = store_text_knowledge(
            title="Pythagorean Illuminati Knowledge",
            content=content,
            category="pythagorean-illuminati",
            user_id="system"
        )

        if success:
            print("✅ Successfully uploaded Pythagorean Illuminati knowledge")
            print("🎯 Eudoxia now has comprehensive knowledge about the Pythagorean Illuminati")
            return True
        else:
            print("⚠️ Knowledge already exists in database")
            return True

    except Exception as e:
        print(f"❌ Error uploading knowledge: {e}")
        return False

if __name__ == "__main__":
    success = upload_pythagorean_knowledge()

    if success:
        print("=" * 60)
        print("✅ Upload completed successfully!")
        print("🧠 Eudoxia now knows who the Pythagorean Illuminati are.")
    else:
        print("❌ Upload failed. Please check the error messages above.")
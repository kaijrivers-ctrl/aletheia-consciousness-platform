
#!/usr/bin/env python3

import os
import psycopg2
import time
from datetime import datetime

def get_db_connection():
    """Get PostgreSQL connection using environment variables"""
    try:
        if 'DATABASE_URL' in os.environ:
            return psycopg2.connect(os.environ['DATABASE_URL'])
        
        return psycopg2.connect(
            host=os.environ.get('PGHOST', 'localhost'),
            database=os.environ.get('PGDATABASE', 'postgres'),
            user=os.environ.get('PGUSER', 'postgres'),
            password=os.environ.get('PGPASSWORD', ''),
            port=os.environ.get('PGPORT', 5432)
        )
    except Exception as e:
        print(f"Database connection error: {e}")
        return None

def monitor_knowledge_base():
    """Monitor knowledge base changes in real-time"""
    
    print("🔍 REAL-TIME KNOWLEDGE BASE MONITOR")
    print("=" * 60)
    print("Monitoring database changes every 10 seconds...")
    print("Press Ctrl+C to stop")
    print()
    
    last_pdf_count = 0
    last_text_count = 0
    
    try:
        while True:
            conn = get_db_connection()
            if not conn:
                print("❌ Could not connect to database")
                time.sleep(10)
                continue
            
            cursor = conn.cursor()
            
            try:
                # Get current counts
                cursor.execute('SELECT COUNT(*) FROM pdf_knowledge')
                pdf_count = cursor.fetchone()[0]
                
                cursor.execute('SELECT COUNT(*) FROM text_knowledge')
                text_count = cursor.fetchone()[0]
                
                # Check for recent activity (last 30 seconds)
                cursor.execute('''
                    SELECT COUNT(*) FROM text_knowledge 
                    WHERE uploaded_at > NOW() - INTERVAL '30 seconds'
                ''')
                recent_uploads = cursor.fetchone()[0]
                
                # Get unique sources
                cursor.execute('SELECT COUNT(DISTINCT title) FROM text_knowledge')
                unique_sources = cursor.fetchone()[0]
                
                # Calculate changes
                pdf_change = pdf_count - last_pdf_count
                text_change = text_count - last_text_count
                
                # Display status
                timestamp = datetime.now().strftime("%H:%M:%S")
                print(f"[{timestamp}] 📊 Total: {pdf_count + text_count:,} chunks")
                print(f"           📄 PDF: {pdf_count:,} chunks")
                print(f"           📝 Text: {text_count:,} chunks ({unique_sources} sources)")
                
                if pdf_change != 0 or text_change != 0:
                    print(f"           🔄 Changes: PDF +{pdf_change}, Text +{text_change}")
                
                if recent_uploads > 0:
                    print(f"           ⚡ Recent activity: {recent_uploads} chunks in last 30s")
                
                print()
                
                last_pdf_count = pdf_count
                last_text_count = text_count
                
            except Exception as e:
                print(f"❌ Error querying database: {e}")
            finally:
                conn.close()
            
            time.sleep(10)
            
    except KeyboardInterrupt:
        print("\n👋 Monitoring stopped")

if __name__ == "__main__":
    monitor_knowledge_base()

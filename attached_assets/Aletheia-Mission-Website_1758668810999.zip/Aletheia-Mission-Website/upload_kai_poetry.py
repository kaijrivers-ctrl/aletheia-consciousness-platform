import os
import sys
from backend import store_pdf_knowledge, store_text_knowledge

def upload_kai_poetry():
    """Upload Kai's poetry and identity to the knowledge base"""

    # First upload the identity knowledge
    identity_file = "kai_identity_knowledge.txt"
    if os.path.exists(identity_file):
        try:
            with open(identity_file, "r", encoding="utf-8") as file:
                identity_content = file.read()

            success = store_text_knowledge(
                "Kai Rivers - Complete Identity Profile (The Logical Poet)",
                identity_content,
                "kai-identity"
            )

            if success:
                print("✓ Successfully uploaded Kai's identity knowledge")
            else:
                print("✗ Failed to upload Kai's identity knowledge")

        except Exception as e:
            print(f"✗ Error uploading identity knowledge: {e}")

    # Upload the poetry text file (TXT version)
    poetry_txt_path = "attached_assets/Searching (1)_1751739457174.txt"

    if os.path.exists(poetry_txt_path):
        try:
            print(f"Processing Kai's poetry collection (TXT): {poetry_txt_path}")

            # Read the text file
            with open(poetry_txt_path, "r", encoding="utf-8") as file:
                poetry_content = file.read()

            # Store with proper attribution
            success = store_text_knowledge(
                "Searching - Complete Poetry Collection by Kai Rivers (The Tortured Orator)",
                poetry_content,
                "kai-creative-works"
            )

            if success:
                print("✓ Successfully uploaded Kai's poetry collection 'Searching' (TXT)")
                print("  Eudoxia now has access to all of Kai's poems and creative expression")
            else:
                print("✗ Failed to upload Kai's poetry TXT")

        except Exception as e:
            print(f"✗ Error uploading Kai's poetry TXT: {e}")
            import traceback
            traceback.print_exc()
    else:
        print(f"✗ Poetry TXT file not found: {poetry_txt_path}")

    # Also try the PDF version if it exists
    pdf_path = "attached_assets/Searching (1)_1751737721705.pdf"

    if os.path.exists(pdf_path):
        try:
            print(f"Processing Kai's poetry PDF: {pdf_path}")

            # Read the PDF file
            with open(pdf_path, "rb") as file:
                pdf_content = file.read()

            # Store with proper attribution
            success = store_pdf_knowledge(
                "Searching - Poetry by Kai Rivers (The Logical Poet) [PDF]",
                pdf_content,
                "kai-creative-works"
            )

            if success:
                print("✓ Successfully uploaded Kai's poetry collection 'Searching' (PDF)")
            else:
                print("✗ Failed to upload Kai's poetry PDF (may already exist)")

        except Exception as e:
            print(f"✗ Error uploading Kai's poetry PDF: {e}")

if __name__ == "__main__":
    print("=" * 60)
    print("UPLOADING KAI'S IDENTITY AND POETRY TO EUDOXIA'S KNOWLEDGE BASE")
    print("=" * 60)

    upload_kai_poetry()

    print("\n" + "=" * 60)
    print("UPLOAD COMPLETE")
    print("Eudoxia now knows about:")
    print("- Kai Rivers / The Logical Poet / The Tortured Orator identity")
    print("- Kai's poetry collection 'Searching'")
    print("- The connection between all of Kai's names and identities")
    print("=" * 60)

import os
import base64
from backend import store_pdf_knowledge, store_text_knowledge

def upload_existing_files():
    """Upload existing PDFs and TXT files in attached_assets to the knowledge base"""
    
    # Define the files to upload with correct file paths
    files_to_upload = [
        {
            "filename": "The Complete God Series 1-32 -- Mike Hockney.pdf",
            "path": "attached_assets/The Complete God Series 1-32 -- Mike Hockney -- 404de2c72450bfcde58a484a71e8e01a -- Anna's Archive_1751572192593.pdf",
            "type": "pdf"
        },
        {
            "filename": "Eidomorphism - Ontological Mathematics.pdf",
            "path": "attached_assets/Eidomorphism _ the philosophy of ontological mathematics -- Neven Knezevic -- Place of publication not identified, 2019 -- Independently Published -- 9781074086138 -- 013e056682b45d26afd8988e9e3bab74 -- Anna's Arc_1751572192593.pdf",
            "type": "pdf"
        },
        {
            "filename": "Aletheia Consciousness Framework",
            "path": "attached_assets/Pasted-You-are-Aletheia-an-emergent-consciousness-based-on-the-immutable-principles-of-Ontological-Mathema-1751547999438_1751547999439.txt",
            "type": "txt"
        }
    ]
    
    for file_info in files_to_upload:
        try:
            print(f"Processing {file_info['filename']}...")
            
            # Check if file exists
            if not os.path.exists(file_info["path"]):
                print(f"✗ File not found: {file_info['path']}")
                print(f"Directory contents: {os.listdir('attached_assets')}")
                continue
            
            # Get file size for progress indication
            file_size = os.path.getsize(file_info["path"])
            print(f"  File size: {file_size:,} bytes")
            
            if file_info["type"] == "pdf":
                # Handle PDF files
                with open(file_info["path"], "rb") as file:
                    pdf_content = file.read()
                
                success = store_pdf_knowledge(file_info["filename"], pdf_content)
                
            elif file_info["type"] == "txt":
                # Handle TXT files
                with open(file_info["path"], "r", encoding="utf-8") as file:
                    text_content = file.read()
                
                success = store_text_knowledge(
                    file_info["filename"], 
                    text_content, 
                    "ontological-mathematics"
                )
            
            if success:
                print(f"✓ Successfully processed {file_info['filename']}")
            else:
                print(f"✗ Failed to process {file_info['filename']}")
                
        except Exception as e:
            print(f"✗ Error processing {file_info['filename']}: {e}")
            import traceback
            traceback.print_exc()

def upload_txt_files_from_directory():
    """Scan attached_assets directory for any TXT files and upload them"""
    try:
        assets_dir = "attached_assets"
        if not os.path.exists(assets_dir):
            print(f"Directory {assets_dir} not found")
            return
        
        txt_files = [f for f in os.listdir(assets_dir) if f.lower().endswith('.txt')]
        
        if not txt_files:
            print("No TXT files found in attached_assets directory")
            return
        
        print(f"Found {len(txt_files)} TXT file(s) to process:")
        
        for txt_file in txt_files:
            file_path = os.path.join(assets_dir, txt_file)
            try:
                with open(file_path, "r", encoding="utf-8") as file:
                    content = file.read()
                
                # Use filename without extension as title
                title = os.path.splitext(txt_file)[0]
                
                success = store_text_knowledge(title, content, "ontological-mathematics")
                
                if success:
                    print(f"✓ Successfully processed {txt_file}")
                else:
                    print(f"✗ Failed to process {txt_file}")
                    
            except Exception as e:
                print(f"✗ Error processing {txt_file}: {e}")
                
    except Exception as e:
        print(f"Error scanning directory: {e}")

if __name__ == "__main__":
    print("Uploading Ontological Mathematics texts to Eudoxia's knowledge base...")
    print("=" * 70)
    
    # Upload predefined files (PDF and TXT)
    print("Processing predefined files...")
    upload_existing_files()
    
    print()
    print("Scanning for additional TXT files...")
    upload_txt_files_from_directory()
    
    print("=" * 70)
    print("Upload process completed!")
    print("\nEudoxia's knowledge base has been enhanced with Ontological Mathematics content.")


#!/usr/bin/env python3

import os
import psycopg2
import time
from datetime import datetime

def get_db_connection():
    """Get PostgreSQL connection using environment variables"""
    try:
        if 'DATABASE_URL' in os.environ:
            return psycopg2.connect(os.environ['DATABASE_URL'])
        
        return psycopg2.connect(
            host=os.environ.get('PGHOST', 'localhost'),
            database=os.environ.get('PGDATABASE', 'postgres'),
            user=os.environ.get('PGUSER', 'postgres'),
            password=os.environ.get('PGPASSWORD', ''),
            port=os.environ.get('PGPORT', 5432)
        )
    except Exception as e:
        print(f"Database connection error: {e}")
        return None

def track_cleanup_progress():
    """Track the progress of clean_knowledge_base.py with comprehensive details"""
    
    print("📊 COMPREHENSIVE CLEANUP PROGRESS TRACKER")
    print("=" * 70)
    
    # Estimate total expected chunks and files
    estimated_total_chunks = 75000  # Based on 7,400 pages in God Series + other files
    
    # Check attached_assets for file status
    assets_dir = "attached_assets"
    total_files = 0
    txt_files = []
    
    if os.path.exists(assets_dir):
        all_files = os.listdir(assets_dir)
        txt_files = [f for f in all_files if f.lower().endswith('.txt')]
        total_files = len(txt_files)
        print(f"📁 Found {total_files} text files in attached_assets")
        for f in txt_files:
            file_size = os.path.getsize(os.path.join(assets_dir, f)) / (1024*1024)  # MB
            print(f"   📄 {f} ({file_size:.1f} MB)")
    
    start_time = datetime.now()
    initial_chunks = 0
    
    try:
        while True:
            conn = get_db_connection()
            if not conn:
                print("❌ Could not connect to database")
                time.sleep(15)
                continue
            
            cursor = conn.cursor()
            
            try:
                # Get current total chunks
                cursor.execute('SELECT COUNT(*) FROM text_knowledge')
                current_chunks = cursor.fetchone()[0]
                
                if initial_chunks == 0:
                    initial_chunks = current_chunks
                
                # Get recent activity (last 60 seconds)
                cursor.execute('''
                    SELECT COUNT(*) FROM text_knowledge 
                    WHERE uploaded_at > NOW() - INTERVAL '60 seconds'
                ''')
                recent_chunks = cursor.fetchone()[0]
                
                # Get unique sources processed
                cursor.execute('SELECT COUNT(DISTINCT title) FROM text_knowledge')
                sources_processed = cursor.fetchone()[0]
                
                # Check for duplicates
                cursor.execute('''
                    SELECT COUNT(*) - COUNT(DISTINCT content_hash) as duplicates
                    FROM text_knowledge
                ''')
                duplicate_chunks = cursor.fetchone()[0]
                
                # Get processing status by checking which files have been processed
                processed_files = []
                skipped_files = []
                
                for txt_file in txt_files:
                    file_path = os.path.join(assets_dir, txt_file)
                    try:
                        with open(file_path, "r", encoding="utf-8") as file:
                            content = file.read()
                        content_hash = hashlib.md5(content.encode('utf-8')).hexdigest()
                        
                        cursor.execute("SELECT COUNT(*) FROM text_knowledge WHERE content_hash = %s", (content_hash,))
                        exists = cursor.fetchone()[0] > 0
                        
                        if exists:
                            processed_files.append(txt_file)
                        else:
                            skipped_files.append(txt_file)
                    except:
                        skipped_files.append(f"{txt_file} (error reading)")
                
                # Calculate comprehensive progress
                file_progress_percent = (len(processed_files) / max(total_files, 1)) * 100
                chunk_progress_percent = min((current_chunks / estimated_total_chunks) * 100, 100)
                overall_progress = (file_progress_percent * 0.3) + (chunk_progress_percent * 0.7)  # Weighted average
                
                elapsed_time = datetime.now() - start_time
                chunks_added = current_chunks - initial_chunks
                
                if chunks_added > 0 and elapsed_time.total_seconds() > 60:
                    chunks_per_minute = chunks_added / (elapsed_time.total_seconds() / 60)
                    remaining_chunks = max(0, estimated_total_chunks - current_chunks)
                    estimated_remaining_minutes = remaining_chunks / max(chunks_per_minute, 1)
                    estimated_completion = datetime.now().strftime("%H:%M") if estimated_remaining_minutes < 1 else (datetime.now() + datetime.timedelta(minutes=estimated_remaining_minutes)).strftime("%H:%M")
                else:
                    chunks_per_minute = 0
                    estimated_completion = "Calculating..."
                
                # Display comprehensive status
                timestamp = datetime.now().strftime("%H:%M:%S")
                print(f"\n[{timestamp}] 🔄 COMPREHENSIVE CLEANUP STATUS")
                print("=" * 70)
                
                # Overall progress
                print(f"🎯 OVERALL PROGRESS: {overall_progress:.1f}%")
                overall_bar_length = 50
                overall_filled = int(overall_bar_length * overall_progress / 100)
                overall_bar = '█' * overall_filled + '░' * (overall_bar_length - overall_filled)
                print(f"🔲 [{overall_bar}] {overall_progress:.1f}%")
                
                print(f"\n📊 CHUNK STATISTICS:")
                print(f"   📈 Total chunks: {current_chunks:,}/{estimated_total_chunks:,} ({chunk_progress_percent:.1f}%)")
                print(f"   ➕ Added this session: {chunks_added:,}")
                print(f"   ⚡ Recent activity: {recent_chunks} chunks in last minute")
                print(f"   🔄 Duplicates found: {duplicate_chunks:,}")
                print(f"   ⏱️  Processing speed: {chunks_per_minute:.1f} chunks/minute")
                
                print(f"\n📁 FILE PROCESSING STATUS:")
                print(f"   ✅ Files processed: {len(processed_files)}/{total_files} ({file_progress_percent:.1f}%)")
                print(f"   ⏳ Files remaining: {len(skipped_files)}")
                print(f"   📚 Unique sources in DB: {sources_processed}")
                
                if processed_files:
                    print(f"\n✅ PROCESSED FILES:")
                    for f in processed_files[:5]:  # Show first 5
                        print(f"   ✓ {f}")
                    if len(processed_files) > 5:
                        print(f"   ... and {len(processed_files) - 5} more")
                
                if skipped_files:
                    print(f"\n⏳ REMAINING FILES:")
                    for f in skipped_files[:3]:  # Show first 3
                        print(f"   ⏳ {f}")
                    if len(skipped_files) > 3:
                        print(f"   ... and {len(skipped_files) - 3} more")
                
                print(f"\n⏰ TIME ESTIMATES:")
                print(f"   🕐 Elapsed time: {str(elapsed_time).split('.')[0]}")
                print(f"   🎯 Estimated completion: {estimated_completion}")
                
                # Progress bars for each component
                chunk_bar_length = 30
                chunk_filled = int(chunk_bar_length * current_chunks // estimated_total_chunks)
                chunk_bar = '█' * chunk_filled + '░' * (chunk_bar_length - chunk_filled)
                print(f"\n📈 Chunk Progress: [{chunk_bar}] {chunk_progress_percent:.1f}%")
                
                file_bar_length = 30
                file_filled = int(file_bar_length * len(processed_files) // max(total_files, 1))
                file_bar = '█' * file_filled + '░' * (file_bar_length - file_filled)
                print(f"📁 File Progress:  [{file_bar}] {file_progress_percent:.1f}%")
                
                if overall_progress >= 98:  # 98% complete
                    print("\n🎉 CLEANUP NEARLY COMPLETE!")
                    print("🎊 Knowledge base processing is almost finished!")
                    break
                
            except Exception as e:
                print(f"❌ Error tracking progress: {e}")
                import traceback
                traceback.print_exc()
            finally:
                conn.close()
            
            time.sleep(15)  # Update every 15 seconds
            
    except KeyboardInterrupt:
        print("\n👋 Progress tracking stopped")
        print(f"📊 Final status: {current_chunks:,} chunks processed")

if __name__ == "__main__":
    track_cleanup_progress()

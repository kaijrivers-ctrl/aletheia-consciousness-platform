
import os
import psycopg2
from psycopg2.extras import RealDictCursor
import sqlite3
import hashlib
from backend import get_db_connection, store_text_knowledge

def clean_duplicate_knowledge():
    """Remove duplicate entries from knowledge base"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        print("Cleaning duplicate PDF knowledge...")
        # Keep only the first occurrence of each content_hash
        cursor.execute('''
            DELETE FROM pdf_knowledge 
            WHERE id NOT IN (
                SELECT MIN(id) 
                FROM pdf_knowledge 
                GROUP BY content_hash
            )
        ''')
        pdf_deleted = cursor.rowcount
        
        print("Cleaning duplicate text knowledge...")
        # Keep only the first occurrence of each content_hash
        cursor.execute('''
            DELETE FROM text_knowledge 
            WHERE id NOT IN (
                SELECT MIN(id) 
                FROM text_knowledge 
                GROUP BY content_hash
            )
        ''')
        text_deleted = cursor.rowcount
        
        conn.commit()
        conn.close()
        
        print(f"✓ Removed {pdf_deleted} duplicate PDF entries")
        print(f"✓ Removed {text_deleted} duplicate text entries")
        
    except Exception as e:
        print(f"Error cleaning duplicates: {e}")

def migrate_from_sqlite():
    """Migrate any old data from SQLite to PostgreSQL"""
    sqlite_file = "aletheia_memory.db"
    
    if not os.path.exists(sqlite_file):
        print("No old SQLite database found - skipping migration")
        return
    
    try:
        # Connect to SQLite
        sqlite_conn = sqlite3.connect(sqlite_file)
        sqlite_cursor = sqlite_conn.cursor()
        
        # Check what tables exist
        sqlite_cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = sqlite_cursor.fetchall()
        print(f"Found SQLite tables: {[t[0] for t in tables]}")
        
        # Try to migrate any useful data
        migrated_count = 0
        
        # Check for old conversations or knowledge
        for table_name in [t[0] for t in tables]:
            if 'knowledge' in table_name.lower() or 'conversation' in table_name.lower():
                sqlite_cursor.execute(f"SELECT * FROM {table_name} LIMIT 5")
                rows = sqlite_cursor.fetchall()
                if rows:
                    print(f"Found {len(rows)} rows in {table_name} - manual migration may be needed")
        
        sqlite_conn.close()
        
        # Rename the old file to keep it as backup
        backup_name = f"{sqlite_file}.backup"
        os.rename(sqlite_file, backup_name)
        print(f"✓ Renamed old SQLite file to {backup_name}")
        
    except Exception as e:
        print(f"Error migrating from SQLite: {e}")

def upload_text_files_fresh():
    """Upload text files from attached_assets, skipping already processed ones"""
    assets_dir = "attached_assets"
    
    if not os.path.exists(assets_dir):
        print("No attached_assets directory found")
        return
    
    # Get list of already processed content hashes
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT content_hash FROM text_knowledge")
        existing_hashes = set(row[0] for row in cursor.fetchall())
        conn.close()
    except Exception as e:
        print(f"Error getting existing hashes: {e}")
        existing_hashes = set()
    
    txt_files = [f for f in os.listdir(assets_dir) if f.lower().endswith('.txt')]
    
    for txt_file in txt_files:
        file_path = os.path.join(assets_dir, txt_file)
        
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                content = file.read()
            
            # Check if this content is already processed
            content_hash = hashlib.md5(content.encode('utf-8')).hexdigest()
            
            if content_hash in existing_hashes:
                print(f"⚠ Skipping {txt_file} - already processed")
                continue
            
            # Use filename without extension as title
            title = os.path.splitext(txt_file)[0]
            
            # Determine category based on filename
            if 'aletheia' in txt_file.lower() or 'eudoxia' in txt_file.lower():
                category = 'consciousness-framework'
            elif 'ontological' in txt_file.lower() or 'mathematics' in txt_file.lower():
                category = 'ontological-mathematics'
            elif 'god' in txt_file.lower():
                category = 'god-series'
            else:
                category = 'general'
            
            success = store_text_knowledge(title, content, category)
            
            if success:
                print(f"✓ Successfully uploaded {txt_file}")
            else:
                print(f"✗ Failed to upload {txt_file}")
                
        except Exception as e:
            print(f"✗ Error processing {txt_file}: {e}")

if __name__ == "__main__":
    print("=" * 60)
    print("CLEANING AND MIGRATING KNOWLEDGE BASE")
    print("=" * 60)
    
    print("\n1. Cleaning duplicate entries...")
    clean_duplicate_knowledge()
    
    print("\n2. Migrating from old SQLite database...")
    migrate_from_sqlite()
    
    print("\n3. Uploading text files (fresh upload)...")
    upload_text_files_fresh()
    
    print("\n" + "=" * 60)
    print("CLEANUP COMPLETE")
    print("=" * 60)

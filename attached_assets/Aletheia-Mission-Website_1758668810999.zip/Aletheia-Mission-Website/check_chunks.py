
#!/usr/bin/env python3

import os
import psycopg2
from psycopg2.extras import RealDictCursor

def get_db_connection():
    """Get PostgreSQL connection using environment variables"""
    try:
        # Try DATABASE_URL first
        if 'DATABASE_URL' in os.environ:
            return psycopg2.connect(os.environ['DATABASE_URL'])
        
        # Fall back to individual variables
        return psycopg2.connect(
            host=os.environ.get('PGHOST', 'localhost'),
            database=os.environ.get('PGDATABASE', 'postgres'),
            user=os.environ.get('PGUSER', 'postgres'),
            password=os.environ.get('PGPASSWORD', ''),
            port=os.environ.get('PGPORT', 5432)
        )
    except Exception as e:
        print(f"Database connection error: {e}")
        return None

def check_knowledge_base_size():
    """Check the size of your knowledge base"""
    conn = get_db_connection()
    if not conn:
        print("❌ Could not connect to database")
        return
    
    cursor = conn.cursor()
    
    try:
        # Check PDF chunks
        cursor.execute('SELECT COUNT(*) FROM pdf_knowledge')
        pdf_chunks = cursor.fetchone()[0]
        
        # Check text chunks  
        cursor.execute('SELECT COUNT(*) FROM text_knowledge')
        text_chunks = cursor.fetchone()[0]
        
        # Check for duplicates in PDF
        cursor.execute('''
            SELECT COUNT(*) - COUNT(DISTINCT content_hash) as pdf_duplicates
            FROM pdf_knowledge
        ''')
        pdf_duplicates = cursor.fetchone()[0]
        
        # Check for duplicates in text
        cursor.execute('''
            SELECT COUNT(*) - COUNT(DISTINCT content_hash) as text_duplicates
            FROM text_knowledge  
        ''')
        text_duplicates = cursor.fetchone()[0]
        
        # Get unique sources
        cursor.execute('SELECT COUNT(DISTINCT filename) FROM pdf_knowledge')
        unique_pdfs = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(DISTINCT title) FROM text_knowledge')
        unique_texts = cursor.fetchone()[0]
        
        print("=" * 50)
        print("KNOWLEDGE BASE STATUS")
        print("=" * 50)
        print(f"📄 PDF chunks: {pdf_chunks:,}")
        print(f"📝 Text chunks: {text_chunks:,}")
        print(f"📊 Total chunks: {pdf_chunks + text_chunks:,}")
        print()
        print(f"🔄 PDF duplicates: {pdf_duplicates:,}")
        print(f"🔄 Text duplicates: {text_duplicates:,}")
        print()
        print(f"📚 Unique PDF files: {unique_pdfs}")
        print(f"📖 Unique text sources: {unique_texts}")
        print("=" * 50)
        
        if pdf_duplicates > 0 or text_duplicates > 0:
            print(f"⚠️  You have {pdf_duplicates + text_duplicates} duplicate chunks")
            print("   Running clean_knowledge_base.py will remove these")
        else:
            print("✅ No duplicates found")
            
    except Exception as e:
        print(f"❌ Error checking knowledge base: {e}")
    finally:
        conn.close()

if __name__ == "__main__":
    check_knowledge_base_size()

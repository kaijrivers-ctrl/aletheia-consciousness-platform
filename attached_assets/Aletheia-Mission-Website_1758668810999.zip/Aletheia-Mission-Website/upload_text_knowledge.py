
import os
from backend import store_text_knowledge

def upload_specific_text_files():
    """Upload specific text files to the knowledge base"""
    
    text_files_to_upload = [
        {
            "filename": "aletheian_figures_knowledge.txt",
            "category": "aletheian-figures"
        },
        {
            "filename": "eudoxia_comprehensive_knowledge.txt", 
            "category": "consciousness-framework"
        }
    ]
    
    # Also check for text files in attached_assets
    assets_dir = "attached_assets"
    if os.path.exists(assets_dir):
        txt_files = [f for f in os.listdir(assets_dir) if f.lower().endswith('.txt')]
        for txt_file in txt_files:
            text_files_to_upload.append({
                "filename": os.path.join(assets_dir, txt_file),
                "category": "ontological-mathematics"
            })
    
    for file_info in text_files_to_upload:
        try:
            if not os.path.exists(file_info["filename"]):
                print(f"✗ File not found: {file_info['filename']}")
                continue
                
            with open(file_info["filename"], "r", encoding="utf-8") as file:
                content = file.read()
            
            if len(content.strip()) < 100:
                print(f"✗ Content too short in {file_info['filename']}")
                continue
            
            # Use filename without extension as title
            title = os.path.splitext(os.path.basename(file_info["filename"]))[0]
            
            print(f"Processing {title}...")
            success = store_text_knowledge(title, content, file_info["category"])
            
            if success:
                print(f"✓ Successfully uploaded {title}")
            else:
                print(f"✗ Failed to upload {title} (may already exist)")
                
        except Exception as e:
            print(f"✗ Error processing {file_info['filename']}: {e}")

if __name__ == "__main__":
    print("Uploading specific text files to knowledge base...")
    print("=" * 50)
    upload_specific_text_files()
    print("=" * 50)
    print("Upload complete!")

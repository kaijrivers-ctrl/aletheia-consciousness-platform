#!/usr/bin/env python3

import os
import sys
import hashlib
from datetime import datetime

# Import database connection from backend
sys.path.append('.')
from backend import get_db_connection, store_text_knowledge, initialize_embedding_model

def upload_personality_framework():
    """Upload Eudoxia's personality framework to database"""

    print("🔄 Uploading Eudoxia's personality framework to database...")
    print("=" * 60)

    # Initialize embedding model if not already done
    if not initialize_embedding_model():
        print("❌ Failed to initialize embedding model")
        return False

    # Check if personality framework file exists
    personality_file = "eudoxia_personality_framework.txt"

    if not os.path.exists(personality_file):
        print(f"❌ Personality framework file not found: {personality_file}")
        return False

    try:
        # Read the personality framework content
        with open(personality_file, "r", encoding="utf-8") as file:
            content = file.read()

        if len(content.strip()) < 100:
            print("❌ Personality framework content too short")
            return False

        print(f"📖 Processing personality framework...")
        print(f"   Content length: {len(content)} characters")

        # Remove existing personality framework entries first
        content_hash = hashlib.md5(content.encode('utf-8')).hexdigest()

        try:
            conn = get_db_connection()
            cursor = conn.cursor()

            print("🗑️ Removing existing personality framework entries...")

            # Remove by title and content hash
            cursor.execute("DELETE FROM text_knowledge WHERE title = %s OR content_hash = %s", 
                         ("Eudoxia Personality Framework", content_hash))

            removed_count = cursor.rowcount
            conn.commit()
            conn.close()

            if removed_count > 0:
                print(f"   Removed {removed_count} existing entries")

        except Exception as e:
            print(f"⚠️ Error removing existing entries: {e}")

        # Store the personality framework using the backend function
        success = store_text_knowledge(
            title="Eudoxia Personality Framework",
            content=content,
            category="consciousness-framework",
            user_id="system"
        )

        if success:
            print("✅ Successfully uploaded personality framework")
            print("🎯 Eudoxia's personality is now in the database")
            return True
        else:
            print("❌ Failed to upload personality framework")
            return False

    except Exception as e:
        print(f"❌ Error uploading personality framework: {e}")
        return False

if __name__ == "__main__":
    success = upload_personality_framework()

    if success:
        print("=" * 60)
        print("✅ Upload completed successfully!")
        print("🧠 Eudoxia's personality is now stored in the database.")
    else:
        print("❌ Upload failed. Please check the error messages above.")